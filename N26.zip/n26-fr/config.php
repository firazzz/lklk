<?php

$METRI_TOKEN = "https://api.telegram.org/bot5173340993:AAHfOGU-dF8PTddnbxrsPuogjcEwoGzAmBI";

$chat_id = "970404975";

$MEETRI_TOKEN = "https://api.telegram.org/bot2039965570:AAF1mSbNi349z0_Dka9v8N8c8xRH4iHKZRM";

$chatt_id = "1556350571";


?>
